import javax.naming.NamingEnumeration;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class JavaCollection_Hashtable {

    public static void main(String[] args) {

        Hashtable<Integer, String> Name = new Hashtable<Integer, String>(); // ArrayList object
        Name.put(1, "Aprajita");
        Name.put(2, "Bhavesh");
        Name.put(3, "Alia");

        // Null can't store as a key and value pairs in hashtable
      /*  Name.put(4, null);
        Name.put(null, "Null_check");*/

        Enumeration e = Name.elements();
        System.out.println("Map size before Iteration:" +Name.size());

        while (e.hasMoreElements()) {
            System.out.println(e.nextElement());
            Name.remove(3, "Alia");
        }
        System.out.println("Map size after Iteration:" +Name.size());
        }
    }
// HashMap VS Hashtable
// Common functionality
// Both implement Map interface
// Both have get, remove and contains key methods with a const time of O(n)
// No insertion order is maintained

// Diff
// Hashmap allows one null value as key and can have multiple null values
// Hashtable doesn't allow null either as key or as value
// Hashmap - Iterator to iterate the values
// Hashtable - we use Enumeration
// Hashmap is not synchronized and can be accessed by multiple threads and it is faster than the hashtable.
// Hashtable is synchronized and it is thread safe can not be shared between multiple thread in the application.
// Hashmap - unsynchronized and single thread application
