import java.util.Scanner;

public class FindElement_Array {
    public static void main(String args[]) {
        int a[] = new int[5]; // Array
        int n, count = 0;
        Scanner sc = new Scanner(System.in); // Scanner = Runtime value input
        System.out.print("Enter Elements in array: ");
        for (int i = 0; i < a.length; i++) {
            a[i] = sc.nextInt(); // input /// 10, 20, 30, 40, 50

        }
        System.out.print("Array Elements: ");
        for (int i = 0; i < a.length; i++) // i = 0, 1, 2, 3, 4, 5
        {
            System.out.print(a[i] + " "); // print

        }
        System.out.print("\n Enter Search Elements: "); // 20
        n = sc.nextInt(); // 20
        for (int i =0 ;i< a.length; i++) {
            if (a[i] == n) // 1== 20 - false , 20 = 20 - true
            {
                count++; // c = 1
            }
        }
           if (count>0){
               System.out.print("Item found "+count+ " times");
           }
           else{
               System.out.print("tem not found");
           }

        }
    }
