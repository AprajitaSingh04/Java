/*
public class This {
    int a; // instance
    This() //default
    {
        this(10);
        System.out.println("Aprajita");
    }
    This(int a ) //parametrized
    {
       // this();
        System.out.println(a);
    }
    */
/*void show ()
        {
            System.out.println(this);
            System.out.println(a);

        }*//*

    public static void main (String args[]){
        This t = new This();
        //This t = new This(100);
        System.out.println(t);
       // t.show();

    }
}
*/


class This{
   /*int a;
   This(int a){
      this.a = a;
   }
   void show(){
        System.out.println(a);
         System.out.println(this);
    }*/


    This() {
        this(10);
        System.out.println("This default constructor ");
    }

    This(int a) {
      //  this();
        System.out.println("This parametrized constructor " +a);
    }

    public static void main (String args[]) {
        This t = new This();
       // This t = new This(100);
       // System.out.println(t);
       // t.show();
    }

    }