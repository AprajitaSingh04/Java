import java.util.Scanner;

public class Array_Reverse {
    public static void main(String args[]) {
        int a[] = new int[5]; // Array
        Scanner sc = new Scanner(System.in); // Scanner = Runtime value input
        System.out.print("Enter elements in array: ");
        for (int i = 0; i < a.length; i++)
        // for (int i = 0 ; i <5; i++)
        {
            a[i] = sc.nextInt(); // input

        }
        /*System.out.print("Array Elements: ");
        for (int i = 0; i < a.length; i++)
        {
            System.out.print( a[i]+ " ");

        }*/
        System.out.print("\n Array Reverse Elements: ");
        for (int i = a.length-1; i >=0; i--)
        {
            System.out.print( a[i]+ " "); // output

        }

    }
}