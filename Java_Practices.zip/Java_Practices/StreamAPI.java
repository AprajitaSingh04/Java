import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class StreamAPI {
    public static void main(String[] args) {

        List <Integer> nums = Arrays.asList(1,2,4,5,6,7,8,9);
     //   Stream <Integer> data = nums.stream();
      //  data.forEach(n-> System.out.println(n));
        /*
        4
        5
        6
        7
        8
        9*/

       // Stream <Integer> sortedData = data.sorted();
       // sortedData.forEach(n-> System.out.println(n));

       /* 4
        5
        6
        7
        8
        9*/

        /*for ( int n : nums) {
            System.out.println(n * 2);
        }*/
            /*8
            10
            12
            14
            16
            18*/
      /*  Stream <Integer> mappeddata = data.map(n -> n*2);
        mappeddata.forEach(n-> System.out.println(n));*/
       /* 8
        10
        12
        14
        16
        18*/

      //  nums.stream()
                int result = nums.stream()
                        .filter(n -> n%2 == 1)
                        .sorted()
                        .map(n -> n*2)
                        .reduce(0, (c,e) -> c+e); // 44
                         System.out.println(result); // 44
        //          .forEachOrdered(n -> System.out.println(n));
       /*  2
           10
           14
           18
*/
        // Anonymous class
      /*  Predicate <Integer> pred1 = new Predicate<Integer>() {
            @Override
            public boolean test(Integer n) {
                if (n%2==1)
                    return true;
                else
                return false;
            }
        };*/

     /* Lambda expression*/
     //   Predicate <Integer> pred1 = n -> n%2 == 1;

    }
    }
