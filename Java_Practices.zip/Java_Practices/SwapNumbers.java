/*Swapping of 2 numbers without using 3rd variables*/
// a = 10, b = 20
// a = 20, b = 10

import java.util.Scanner;
import java.util.Scanner;

public class SwapNumbers {
    public static void main(String args[]){
             int a , b;
                System.out.println("Enter any two number:" );
                Scanner sc = new Scanner(System.in);
                a = sc.nextInt(); // a =100
                b = sc.nextInt();// b = 200
        System.out.println("Before swapping: "+a+ " "+b ); // 100 200

                a = a+b; // a = 100+200 = 300
                b = a-b; // b = 300 - 200 = 100
                a = a-b; // a = 300 - 100 = 200
        System.out.println("After swapping: "+a+ " "+b ); // 200 100

                 /*Swapping of two var with using 3rd var*/
   //Ram --> 10 Shyaam --> 20
   // Ram --> 20 <--> Raju <---> Shyam --> 10


       /* int a , b, temp;
        System.out.println("Enter any two number:" );
        Scanner sc = new Scanner(System.in);
        a = sc.nextInt(); // a =100
        b = sc.nextInt();// b = 200

        System.out.println("Before swapping: "+a+ " "+b ); // 100 200

        temp = a; // temp = 100
        a = b; // a = 200
        b = temp; // b = 100
        System.out.println("After swapping: "+a+ " "+b ); // 200 100
*/

    }
}
