import java.util.Scanner;

public class Armstrong_Number {

    public static void main (String args[]) {
        int n, s=0, rem=0, c; // n = 153
        System.out.println("Enter any Number: ");
        Scanner sc =new Scanner(System.in);
        n = sc.nextInt();
        c = n; // c = 153
        while (n>0){
            rem = n%10;// 153%10 = 15 = n and r = 3
            s = (rem*rem*rem) + s; // s = 27
            n = n/10; // n = 15

        }
        if (c == s){
            System.out.println("Armstrong number ");
        }
        else {
            System.out.println("Not a Armstrong number ");
        }
    }
}
