import java.util.Scanner;

public class Copy_Array_Elements {
    public static void main(String args[]) {
        int a[] = new int[5]; // Array
        int b[] = new int[5];
        Scanner sc = new Scanner(System.in); // Scanner = Runtime value input
        System.out.print("Enter value in first array: ");
        for (int i = 0; i < a.length; i++)
        {
            a[i] = sc.nextInt(); // input

        }
        System.out.print("First Array Elements: ");
        for (int i = 0; i < a.length; i++)
        {
            System.out.print( a[i]+ " "); // print

        }
        System.out.print("\n Second Array Elements: ");
        for (int i =0 ;i< b.length; i++)
        {
            b[i] = a[i];
            System.out.print( b[i]+ " "); // output - copy

        }
    }
}