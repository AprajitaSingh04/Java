class Human {

    public int walk(int distance, int time) {
        int speed = distance / time;
        return speed;
       // System.out.println("super speed: " +speed);
    }
}
class Athlete extends  Human {
        public int walk(int distance, int time) {
         //   super.walk(1000,500);
            int speed = distance / time;
            speed = speed * 2;
            return speed;
          //  System.out.println("sub speed: " +speed);

        }
    }
    public class Overriding_practice {
    public static void main (String args[]){
        Human s = new Athlete();
        int walk1 = s.walk(500,25);
        int walk2 = s.walk(200, 40);
        System.out.println(walk1);
        System.out.println(walk2);
      //  s.walk(500,25);
    }
}



 /*class Human {
     void walk(int dist, int time){
         int speed = dist/time;
      //   return speed;
         System.out.println(speed);

     }

 }
 class Athlete extends Human{
     void walk(int dist, int time){
         int speed = dist/time;
         speed = speed * 2;
         System.out.println(speed);
      //   return speed;
     }

 }

     public class Overriding_practice {
     public static void main (String args[]){
         Human h = new Athlete();
         h.walk(3000, 10);
         }

 }*/

/* class Human{
    void walk (int dist, int time){
        int speed = dist/time;
        System.out.println("super speed:" +speed) ;
    }
}
class Athlete extends Human{
    void walk (int dist, int time){
        super.walk(45,3);
        int speed = dist/time;
        speed = speed*2;
        System.out.println("sub speed :" +speed) ;
    }
}
public class Overriding_practice {
    public static void main (String args[]){
        Human h = new Athlete();
        h.walk(2000,10);


    }
}

*/