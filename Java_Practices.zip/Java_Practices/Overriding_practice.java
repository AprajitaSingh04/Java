 /*class Human {

    public int walk(int distance, int time) {
        int speed = distance / time;
        return speed;

    }
}
class Athelete extends  Human {
        public int walk(int distance, int time) {
            int speed = distance / time;
            speed = speed * 2;
            return speed;

        }
    }
    public class Overriding_practice {
    public static void main (String args[]){
        Human s = new Athelete();
        int walk1 = s.walk(50,12);
        int walk2 = s.walk(23, 11);
        System.out.println(walk1);
        System.out.println(walk2);
    }
}
*/

 class Human {
     void walk(int dist, int time){
         int speed = dist/time;
      //   return speed;
         System.out.println(speed);

     }

 }
 class Athlete extends Human{
     void walk(int dist, int time){
         int speed = dist/time;
         speed = speed * 2;
         System.out.println(speed);
      //   return speed;
     }

 }

     public class Overriding_practice {
     public static void main (String args[]){
         Human h = new Athlete();
         h.walk(3000, 10);
         }

 }
