class superclass // Super Class
{
    /*superclass() // default const
    {
        System.out.println("Hello......");
    }*/
    void show()
    {
        System.out.println("Hello coding");

    }
    superclass(int a) // parametrized const
    {
        System.out.println("Hello int: " +a);
    }
}
class superclass1 extends superclass // Super Class
{
    superclass1() // default const
    {
        // super
        super(100);
        System.out.println("Hi....");

    }
    void show()
    {
        super.show(); // super
        System.out.println("Hi Learner");

    }
}
public class Super {
    public static void main (String args[]){
        superclass1 s = new superclass1();
        s.show();

    }

}
