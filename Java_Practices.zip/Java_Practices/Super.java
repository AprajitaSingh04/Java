class superclass // Super Class
{
    /*superclass() // default const
    {
        System.out.println("Hello......");
    }*/
    void show()
    {
        System.out.println("Hello coding");

    }
    superclass(int a) // parametrized const
    {
        System.out.println("Hello int: " +a);
    }
}
class superclass1 extends superclass // Super Class
{
    superclass1() // default const
    {
        // super
        super(100);
        System.out.println("Hi....");

    }
    void show()
    {
        super.show(); // super
        System.out.println("Hi Learner");

    }
}
public class Super {
    public static void main (String args[]){
        superclass1 s = new superclass1();
        s.show();

    }

}
// super will be defined by default in default const.
// super should be user defined in parametrised const.


/*
class Super1{
    // int a = 10;

  /* Super1(){
        System.out.println("Hi from Super class const");
    }*//*


    // super will be defined by default in default const.
    Super1(int a ){
        System.out.println("Hi from Super class const " +a); // super should be user defined in parametrised const.
    }
  void show(){
      System.out.println("Hi from Super class");
  }
}

class Super2 extends Super1{
    Super2(){
        super(500);
        System.out.println("Hi from Sub class Const.");
    }
    void show(){
       // int a = 20;
       // System.out.println(a);
       // System.out.println(super.a);
        super.show();
        System.out.println("Hi from Sub class");
    }

}
public class Super {
    public static void main (String args[]) {
        Super2 s2 = new Super2();
      //  s2.show();
    }
    }*/
