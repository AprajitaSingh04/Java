import java.util.Scanner;

public class Sum_EvenOdd {
    public static void main(String args[]) {

        int n, sum =0;
        System.out.print("Enter Range:"); // 10
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        if (n%2 == 0) {
            for (int i = 0; i <= n; i= i+2) // 0, 2, 4, 6 , 8, 10
            {
                sum = sum +i; // 30
            }

                System.out.print( "Sum of Even number: " +sum);

        }
        else {
            for (int i = 1; i <= n; i= i+2) // 1, 3, 5, 7 , 9 , 11
            {
                sum = sum + i; // 36
            }
                System.out.print("Sum of Odd number: " +sum);

        }

    }
}
