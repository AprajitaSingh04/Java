package package2;


//The main difference between the default and protected access modifiers is the scope of accessibility.

import package1.Myclass_defProtected;

public class SubClass_defProtected extends Myclass_defProtected {

        public void myMethod() { // protected access modifier
            System.out.println("This is a protected method:" + y); // protected = accessible
            // System.out.println("This is a default method: " +x); // default not accessible
        }
    }