import java.util.Scanner;

public class Even_Odd_Number {
    public static void main(String args[]) {

        int n;
        System.out.print("Enter a number:");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
            if (n%2 == 0){
                System.out.print(n+ " is Even");
            }
            else{
                System.out.print(n+ " is odd");
            }
        /*if (n%2 == 0) {
            for (int i = 0; i <= n; i= i+2) {
            }
            System.out.print( "Even number: " +n);

        }
        else{
            System.out.print( "Odd number: " +n);
        }*/
    }


    }
