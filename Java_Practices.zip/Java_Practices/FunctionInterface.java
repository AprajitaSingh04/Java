import package1.Myclass_defProtected;

import java.util.Arrays;/*

@FunctionalInterface
interface FunctionInterface {
        void doSomething();

}

    FunctionInterface myFunc =  () -> {
    System.out.println("Doing Something...!! ");
    myFunc.doSomething();
};
*/

/*
// Stream API
import java.util.List;
import java.util.Arrays;


List<String> names = Arrays.asList("Appp", "Bsss", "Cgggg", "hsss");
names.stream()
.filter(names -> names.startsWith("J"))
.map(String::toUpperCase)
.forEach(System.out.println);*/

// Default and Static comparison

interface FunctionInterface {

    default void defaultMethod(){
        System.out.println("This is a Default Method");
    }

    static void staticMethod(){
        System.out.println("This is a static Method");
    }
}

class Myclass implements FunctionInterface{
    public static void main(String args[]) {
        Myclass mc = new Myclass();
        mc.defaultMethod();
        FunctionInterface.staticMethod();

    }
    }

