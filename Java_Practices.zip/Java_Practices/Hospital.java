public class Hospital {

     int b;
     int a;
     double c;

     public Hospital(int doctors, int nurses) {
         b = doctors;
         a = nurses;
     }

     public Hospital(int doctors) {
         b = doctors;
     }

     public Hospital(double salaries) {
         c = salaries;
     }

     public static void main(String args[]) {
         Hospital h = new Hospital(10,20);
         Hospital h1 = new Hospital(30);
         Hospital h2 = new Hospital(5000.00);
         System.out.println(h.b +" " + h.a );
         System.out.println(h1.b );
         System.out.println(h2.c );
     }

 }