
public class Hospital {

     int b;
     int a;
     double c;

     public Hospital(int doctors, int nurses) {
         b = doctors;
         a = nurses;
     }

     public Hospital(int doctors) {
         b = doctors;
     }

     public Hospital(double salaries) {
         c = salaries;
     }

     public static void main(String args[]) {
         Hospital h = new Hospital(10,20);
         Hospital h1 = new Hospital(30);
         Hospital h2 = new Hospital(5000.00);
         System.out.println(h.b +" " + h.a );
         System.out.println(h1.b );
         System.out.println(h2.c );
     }

 }


/*
public class Hospital {
    int a; String b; double c;

    Hospital(){
        a = 100; b = "ABC"; c =9087.90;
        System.out.println("Default block");

    }
    Hospital(int doctors, String nurses){
        a = doctors; b = nurses;
        System.out.println("parametrized1 block");

    }
    Hospital(double salary){
        c = salary;
        System.out.println("parametrized2 block");

    }


    public static void main(String args[]) {

        Hospital h = new Hospital();
        Hospital h1 = new Hospital(45, "Apru");
        Hospital h2 = new Hospital(678990.90);

        System.out.println(h.a+ " " +h.b+ " "+h.c);
        System.out.println(h1.a+ " " +h1.b);
        System.out.println(h2.c);


    }


    }
*/
