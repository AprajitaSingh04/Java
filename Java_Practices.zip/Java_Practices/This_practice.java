public class This_practice {
        int a; // instance
    This_practice() //default
        {
           // this (10);
            System.out.println("Aprajita");
        }
    This_practice(int a ) //parametrized
        {
             this();
            System.out.println(a);
        }
        void show ()
            {
               // System.out.println(this);
                System.out.println(100000);

            }
        public static void main (String args[]){
            //This_practice t = new This_practice();
            This_practice t = new This_practice(100);
           // System.out.println(t);
            t.show();

        }
    }


