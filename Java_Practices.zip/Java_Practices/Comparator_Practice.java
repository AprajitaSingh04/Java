import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Comparator_Practice {

    public static void main(String args[]) {
        List<String> name = Arrays.asList("App", "Abb", "Cddd", "Efff", "Baaa");
        name.sort(Comparator.comparing(String::length).thenComparing(String::compareToIgnoreCase));
        System.out.println(name);

    }

   /* public static Comparator<Student_Comparable_Practice> NameComparator = new Comparator<Student_Comparable_Practice>()

    {
        @Override
        public int compare (Student_Comparable_Practice s1, Student_Comparable_Practice s2){
        return s1.getName().compareTo(s2.getName());
    }
    };

    List<String> names = Arrays.asList("Appu", "Cutf", "srdg", "rtyuyu");
    names.sort(Comparator.comparing(String::length).thenComparing(String::compareToIgnoreCase));
    System.out.println(names);



*/




}
