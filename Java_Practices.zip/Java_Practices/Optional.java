//import java.util;
public class Optional {
    public static void main(String args[]) {
        // 1st example
        String str = ""; // if condtn will be executed
        java.util.Optional<String> opt = java.util.Optional.of(str);
        
        if (opt.isPresent()) {
            System.out.println("Value is present: "); // print
        }
        else{
            System.out.println("Value is not present: ");
        }

        //2nd example
        String str1 = "CloudTech";
        java.util.Optional<String> optional = java.util.Optional.ofNullable(str1); // cloudTech

            System.out.println("Value is: " + optional.get());

        //3rd example - NoSuchElementException
       /* String str2 = null;
        java.util.Optional<String> optional1 = java.util.Optional.ofNullable(str2);

        System.out.println("Value is: " + optional1.get()); // NoSuchElementException due to null
*/
        // Handle NoSuchElementException
        String str3 = null ; // try with "Aprajita"
        java.util.Optional<String> optional2 = java.util.Optional.ofNullable(str3);

        if (optional2.isPresent()) {
            System.out.println("Value is present: " +optional2.get());
        }
        else{
            System.out.println("Value not present: ");
        }

        //4th example - Default values
        // if the values default then it will enter into else condition

        String str4 = null ; // try with "Aprajita"
        java.util.Optional<String> optional3 = java.util.Optional.ofNullable(str4);

        if (optional3.isPresent()) {
            System.out.println("Value is present: " +optional3.get());
        }
        else{
            String value = optional3.orElse("Default values"); // if the values is not present it will return default if the values is present it will return actual values
            System.out.println("Value not present: " + value);
        }

    }
}
