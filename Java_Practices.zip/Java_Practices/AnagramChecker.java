
import java.util.Arrays;
import java.util.Scanner;

public class AnagramChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // input from rwo String
        String s1 = "LISTEN";
     //   String s1 = sc.nextLine();
        String s2 = "SILENT";
     //   String s2 = sc.nextLine(); // runtime Exception
        if (isAnagram(s1, s2)) {
            System.out.println(s1 + " and " + s2 + " are anagrams.");
        } else {
            System.out.println(s1 + " and " + s2 + " are not anagrams.");
        }
    }


    public static boolean isAnagram(String s1, String s2) {
        //check for length
        if (s1.length() != s2.length()) {
            return false;
        }

        //convert string into char Array
        char[] charArray1 = s1.toCharArray();
        char[] charArray2 = s1.toCharArray();

        // sort the array

        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        // Compare the sorted char arrays

        return Arrays.equals(charArray1, charArray2);
    }

}

