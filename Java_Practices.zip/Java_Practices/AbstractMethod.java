abstract class programming{
    public abstract void developer();
    public abstract void Rank();
   /* public void draw(){
        System.out.println("Non Abstract method");

    }*/

}

abstract class HTML extends programming{
    @Override
    public void developer(){
        System.out.println("tim Berners Lee");
    }
  /*  @Override
    public void Rank(){
        System.out.println("1st");
    }*/
}
class JAVA extends HTML{
// class JAVA extends programming{
   /* @Override
    public void developer(){
        System.out.println("James Gosling");
    }*/
    @Override
    public void Rank(){
        System.out.println("2nd");
    }
}
public class AbstractMethod {
    public static void main (String args[]) {
      //  programming p = new HTML();
     //   p.developer();p.Rank();
      //  HTML h = new HTML();
      //  JAVA j = new JAVA();
        // h.developer();
       // j.developer();
        programming p1 = new JAVA();
        p1.Rank();p1.developer();
       // p1.draw();
    }
    }
