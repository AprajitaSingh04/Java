import java.util.ArrayDeque;
import java.util.Stack;


public class JavaCollection_Stack {
    public static void main(String[] args) {
        // Pre-defined ArrayList class
        // pre-defined method
        Stack<String> Name = new Stack<>(); // LIFO
        // add
        /*Name.add("Aprajita");
        Name.add("Bhavesh");
        Name.add("Alia");*/

        // push - insert the element - Stack has own method
        Name.push("Aprajita");
        Name.push("Bhavesh");
        Name.push("Alia");

        System.out.println(Name);//  print
        Name.pop(); // remove the element from the last - LIFO
        System.out.println(Name);//  print

        // FIFO
        ArrayDeque<String> Name1 = new ArrayDeque<>(); // FIFO
        // push - insert the element - Stack has own method
        // below result will be incorrect that is why in array it is recommended to use add() and remove()
        /*Name1.push("Aprajita"); // insert the element
        Name1.push("Bhavesh");
        Name1.push("Alia");
        System.out.println(Name1);//  print
        Name1.pop(); // remove the element from the first - FIFO
        System.out.println(Name1);//  print*/

        Name1.add("Aprajita"); // insert the element
        Name1.add("Bhavesh");
        Name1.add("Alia");


        System.out.println(Name1);//  print
        Name1.remove(); // remove the element from the first - FIFO
        System.out.println(Name1);//  print

    }
}