import java.util.Scanner;

public class Palindrome {
    public static void main (String args[]) {
        int n, s=0, r, c; // n = 121
        System.out.println("Enter any Number: ");
        Scanner sc =new Scanner(System.in);
        n = sc.nextInt();
        c = n; // c = 121
        while (n>0) {
            r = n%10;// 121%10 = 12 = n and r = 1
            s = (s*10) +r; // r = s = 1
            n = n/10; // n = 12
        }

        if (c == s) // c = s = 121
        {
            System.out.println("Palindrome number ");
        }
        else {
            System.out.println("Not a Palindrome number ");
        }

    }
}
