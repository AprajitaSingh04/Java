public class Copy_Constructor_Practice {

    int a; String b;
    Copy_Constructor_Practice (int x, String y ){
        a = x; b = y;
        System.out.println(a+ " " +b);

    }
    Copy_Constructor_Practice ( Copy_Constructor_Practice ref ){
        a =  ref.a ;
        b = ref.b;
        System.out.println(a+ " " +b);
    }


    public static void main(String args[]) {
        Copy_Constructor_Practice c  = new Copy_Constructor_Practice(9876, "copy constructor"); // copy
        Copy_Constructor_Practice c1 = new Copy_Constructor_Practice(c); // copy ref_parametrized
    }
}
