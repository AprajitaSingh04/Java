
/*Sum of Digits*/
// input number 126 ---> (1+2+6)

import java.util.Scanner;

public class SumofDigits {
    public static void main(String args[]) {

        int n,r, sum = 0;
        System.out.println("Enter any Number: ");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt(); // 126

        while (n>0)
        {
            r = n%10; // 126%10 =  r = 6, n = 12, 12%10 = r = 2, 1%10 = 1
            sum = sum+r; // sum = 0+6 = 6, 6+2=8=sum, 8+1 = 9= sum
            n = n/10; // n = 12, 1, 1/10 = 0.1 -> consider 0 only
        }
        System.out.println("Sum of Digits: " + sum);
    }
}