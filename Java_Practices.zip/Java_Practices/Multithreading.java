class FirstExample extends Thread {


    public void run(){
        try{
      for (int i = 0; i<=4; i++) {
          System.out.println("Aprajita");
          Thread.sleep(1000);
      }
      }
         catch (InterruptedException e) {
           // throw new RuntimeException(e);
        }
    }
}

public class Multithreading {

    public static void main (String args[]) throws  InterruptedException {
        FirstExample t = new FirstExample();
        t.start();
        for (int i = 0; i<=4; i++){
            System.out.println ("Appu");
            Thread.sleep(1000);
        }
    }
}



/*class FirstExample extends Thread {
    public void run(){
        System.out.println("Aprajita");
    }
}

public class Multithreading {
    public static void main (String args[]) {
        FirstExample t = new FirstExample();
        t.start();

    }
}*/
