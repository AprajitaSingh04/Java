public class ExceptionCoding {
    public static void main(String args[]) {
    //String a = "null";
   String a = "Appu";
    //String a = "1234";
    try {
        int str = Integer.parseInt(a); // NumberFormatException
      //  System.out.println(a.toUpperCase());
        System.out.println(str);
        System.out.println("NumberFormatException");

    }
   catch(NumberFormatException n)
    {
        System.out.println("String "+a+" can't be converted to Integer ");
        }
        System.out.println("Main method ended ");
    }
}
