public class ThrowVSThrows  {
    void div(int a, int b) throws ArithmeticException {
        if (b == 0){
            throw new ArithmeticException();
        }
       else {
           int c = a/b;
            System.out.println(c);
        }

    }

    public static void main(String args[]) {
        ThrowVSThrows t = new ThrowVSThrows();
       // t.div(20, 0); // try with b = 2
        try {
            t.div(20, 0); // try with b = 2
        }
        catch (Exception e ){
            System.out.println(" The value of b is zero");

        }

    }
}
