public class NestedCatch {
    public static void main(String args[]) {

            try {
                int x = 20, y = 0, z; // try with y =0 ; Exception throws
                z = x / y;
               System.out.println(z);// No use
            }
            catch (ArithmeticException e) {
                System.out.println(e);
                try {
                  String str = null;
                   // String str = "APRA";
                    System.out.println(str.toUpperCase());
                   // System.out.println(str.toLowerCase());
                } catch (NullPointerException n) {
                    System.out.println("Null Value can't be converted ");

                }
            }
        finally
        {
            System.out.println("finally block ");
        }
        System.out.println("Main method ended ");
    }
}
