public class StaticBlock {
   /* static{
        System.out.println("Want to learn Coding");
    }*/

    public static void main(String args[]) {
        StaticBlock s = new StaticBlock();
    }
    StaticBlock (){
        System.out.println("learn Java"); // Constructor
    }
    {
        System.out.println("learn Coding"); // Instance block
    }
    static{
        System.out.println("Want to learn Coding"); // Static
    }
}

// Static will execute first, Instance block then Constructor