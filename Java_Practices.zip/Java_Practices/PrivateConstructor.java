class A {
    static int k; int a;
    double b;
    boolean c;

    private A() // Default
    {
        a = 10;
        b = 45.78;
        c = true;
        k = 67;
        System.out.println(a + " " + b + " " + c);
    }
      static void Disp() {
        System.out.println(k);
    }
    public static void main(String args[]) {
        A e = new A();
        e.Disp();
    }
}
/*
class PrivateConstructor {
    public static void main(String args[]) {
        A e = new A();

    }
}*/
