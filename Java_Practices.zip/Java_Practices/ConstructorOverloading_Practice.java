
public class ConstructorOverloading_Practice {
    int x ; String y; double z;
    ConstructorOverloading_Practice(){
        x = 100; y = "Hello Costructor";
        System.out.println("1st block");
    }
    ConstructorOverloading_Practice(int a, String b){
        x = a;y =b;
        System.out.println("2nd block");

    }
    ConstructorOverloading_Practice(int a, double d){
        x = a; z= d;
        System.out.println("3rd block");
    }

    public static void main(String args[]) {
        ConstructorOverloading_Practice c = new ConstructorOverloading_Practice();
        ConstructorOverloading_Practice c1 = new ConstructorOverloading_Practice(12, "There");
        ConstructorOverloading_Practice c2 = new ConstructorOverloading_Practice(20, 40.9);
        System.out.println(c.x + " " + c.y + " " + c.z);
        System.out.println(c1.x+ " " +c1.y);
        System.out.println(c2.x + " " +c2.z);


    }
}

/*
public class ConstructorOverloading_Practice{
    int var1; double var2; String var3;
    ConstructorOverloading_Practice(double salary){
        System.out.println("1st block");
        var2 = salary;
    }

    ConstructorOverloading_Practice(int doctors, String nurses){
        System.out.println("2nd block");
         var3 = nurses;
        var1 = doctors;
    }

    ConstructorOverloading_Practice(){
        System.out.println("3rd block");
        var1= 13; var2= 4365.89; var3 = "Akku";
    }

    public static void main(String args[]) {
        ConstructorOverloading_Practice h = new ConstructorOverloading_Practice(4678.00);
        ConstructorOverloading_Practice h1 = new ConstructorOverloading_Practice(12,"Apra");
        ConstructorOverloading_Practice h2 = new ConstructorOverloading_Practice();

        System.out.println(h.var2);
        System.out.println(h1.var3);
        System.out.println(h2.var1+ " " +h2.var2+" "+h2.var3);


    }}
*/
