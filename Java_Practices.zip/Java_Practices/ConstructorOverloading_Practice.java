public class ConstructorOverloading_Practice {
    int x ; String y; double z;
    ConstructorOverloading_Practice(){
        x = 100; y = "Hello Costructor";
        System.out.println("1st block");
    }
    ConstructorOverloading_Practice(int a, String b){
        x = a;y =b;
        System.out.println("2nd block");

    }
    ConstructorOverloading_Practice(int a, double d){
        x = a; z= d;
        System.out.println("3rd block");
    }

    public static void main(String args[]) {
        ConstructorOverloading_Practice c = new ConstructorOverloading_Practice();
        ConstructorOverloading_Practice c1 = new ConstructorOverloading_Practice(12, "There");
        ConstructorOverloading_Practice c2 = new ConstructorOverloading_Practice(20, 40.9);
        System.out.println(c.x + " " + c.y + " " + c.z);
        System.out.println(c1.x+ " " +c1.y);
        System.out.println(c2.x + " " +c2.z);


    }
}
