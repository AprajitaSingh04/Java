 class Super_practice1 {
    Super_practice1(){
        System.out.println("Super const");
    }
    Super_practice1(String a, int b){
        System.out.println(a + " " + b);
    }
    void foo(){
        System.out.println("Method");

    }
}
public class Super_practice extends  Super_practice1 {

    Super_practice(){
      //  super();
        super ("Super", 6);
        System.out.println("Sub const");
    }

    void foo(){
        super.foo();
        System.out.println("child Method");

    }

    public static void main (String args[]){
        Super_practice s = new Super_practice();
        s.foo();

    }
}
