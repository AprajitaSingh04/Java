class DefaultAndParametrized {
    int a; String b; boolean c;
    DefaultAndParametrized() // Default
    {
        a = 10;
        b = "Aprajita";
        c = true;
    }
    DefaultAndParametrized(int x, String y) // parametrized
    {
        a = x; b = y;
    }
    DefaultAndParametrized(int f, String g, boolean h) // parametrized
    {
        a = f; b = g; c = h;
    }
    void Disp() {
        System.out.println(a+ " " +b+ " " +c);
    }
}
public class Constructor {
    public static void main (String args[]){
        DefaultAndParametrized e = new DefaultAndParametrized(); // Default
        DefaultAndParametrized e1 = new DefaultAndParametrized(1020,"Appu");// parametrized
        DefaultAndParametrized e2 = new DefaultAndParametrized(1440,"Aps", false); // parametrized
        e.Disp(); // Default
        e1.Disp(); // parametrized
        e2.Disp(); // parametrized


    }
}
