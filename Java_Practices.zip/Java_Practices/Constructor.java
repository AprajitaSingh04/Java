

class DefaultAndParametrized {
    int a; String b; boolean c;
    DefaultAndParametrized() // Default
    {
        a = 10;
        b = "Aprajita";
        c = true;
    }
    DefaultAndParametrized(int x, String y) // parametrized
    {
        a = x; b = y;
    }
    DefaultAndParametrized(int f, String g, boolean h) // parametrized
    {
        a = f; b = g; c = h;
    }
    void Disp() {
        System.out.println(a+ " " +b+ " " +c);
    }
}
public class Constructor {
    public static void main (String args[]){
        DefaultAndParametrized e = new DefaultAndParametrized(); // Default
        DefaultAndParametrized e1 = new DefaultAndParametrized(1020,"Appu");// parametrized
        DefaultAndParametrized e2 = new DefaultAndParametrized(1440,"Aps", false); // parametrized
        e.Disp(); // Default
        e1.Disp(); // parametrized
        e2.Disp(); // parametrized


    }
}

/*
class DefaultAndParametrized {
    String a;
    int b;

    DefaultAndParametrized() {
        a = "Aprajita";
        b = 10;

    }

    DefaultAndParametrized(String c, int y) {
        a = c;
        b = y;

    }

    DefaultAndParametrized(DefaultAndParametrized ref) {
        a = ref.a;
        b = ref.b;
        System.out.println(a+ " " +b);

    }

    void Disp() {
        System.out.println(a + " " + b);
    }
}

     public class Constructor{
            public static void main (String args[]) {
                DefaultAndParametrized c1 = new DefaultAndParametrized();
                DefaultAndParametrized c2 = new DefaultAndParametrized("Appu", 20);
                DefaultAndParametrized c3 = new DefaultAndParametrized(c2); //  // copy
                c1.Disp();
                c2.Disp();

    }
    }
*/
