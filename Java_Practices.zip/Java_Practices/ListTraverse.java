import java.util.ArrayList;
import java.util.List;

public class ListTraverse {
    public static void main(String[] args) {
// Pre-defined ArrayList class
        // pre-defined method
        List<String> str = new ArrayList<>(); // LinkedList object
        str.add("Aprajita");
        str.add("Bhavesh");
        str.add("Alia");

        //  1st Approach
        // Simple loop
        // start = 0; end = size-1
        for (int i = 0; i <= str.size() - 1; i++) {
            System.out.println(str.get(i));

        }
        System.out.println("++++++++++++++++++++++++");

        // 2nd Approach
        // for each: collection, list, set
        for (String str2 : str) {
            System.out.println(str2);

        }
        System.out.println("++++++++++++++++++++++++");

        // 3rd Approach - using Iterator - forward
        // 4th Approach - ListIterator - forward and backward



        // 5th Approach

        System.out.println("ForEach Loop after java 8 - Lambda expression");
        str.forEach((element)->{
            System.out.println(element);

        });
        System.out.println("++++++++++++++++++++++++");
    }

}

