import java.util.Scanner;

public class Pattern {
    public static void main (String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("How many rows you want this in pattern: ");
        int rows = sc.nextInt();
        System.out.println("Here is your pattern....!!");
      //  int count = 1;
        for (int i = 1; i<=rows;i++){
            for (int j = 1; j <= i ; j++) {
                System.out.print(j + " ");
            //    System.out.print(i+ "");
              //  System.out.print(count + " ");
              //  count++;
            }
            System.out.println();
        }
        sc.close();
    }
    }
