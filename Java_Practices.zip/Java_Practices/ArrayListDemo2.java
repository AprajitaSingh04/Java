import java.util.ArrayList;
import java.util.Collections;

public class ArrayListDemo2 {

    public static void main(String[] args) {
        //Declare arrayList
        // ArrayList al = new ArrayList(); // Heterogeneous
        // ArrayList <Integer> al = new ArrayList <Integer>(); // Homogeneous
        // ArrayList <String> al = new ArrayList <String>(); // Homogeneous
        // List al = new ArrayList();
        ArrayList al_dup = new ArrayList(); // Heterogeneous

        // Add new elements to the ArrayList
        al_dup.add("X");
        al_dup.add("Y");
        al_dup.add("Z");
        al_dup.add("A");
        al_dup.add("B");

        ArrayList al_dup2 = new ArrayList();
        al_dup2.addAll(al_dup);
        System.out.println(al_dup2); // [X, Y, Z, A, B]

        // remove
        al_dup2.removeAll(al_dup);
        System.out.println("After removing:" +al_dup2); // []

        // sort ---- Collection sort()

        System.out.println("Elements in the array list: " +al_dup); // [X, Y, Z, A, B]
        Collections.sort(al_dup);
        System.out.println("Elements in the array list after sorting : " +al_dup); // [A, B, X, Y, Z]

        // reverse
        Collections.sort(al_dup, Collections.reverseOrder());
        System.out.println("Elements in the array list reverse order : " +al_dup); // [Z, Y, X, B, A]

        // Shuffling - collections.shuffle()

        Collections.shuffle(al_dup);
        System.out.println("Elements in the array list after Shuffling : " +al_dup); // [Y, X, B, A, Z]


    }
}