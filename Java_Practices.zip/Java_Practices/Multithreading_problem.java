
//Multithreading problem
//Bus = TwelveExample
class TwelveExample implements Runnable {
    int available = 1, passenger ;
    TwelveExample (int passenger){
        this.passenger = passenger;  //passenger = 1
    }
    public void run() {
        String name = Thread.currentThread().getName();
        if (available >= passenger) // 1>=1
        {
            System.out.println (name+" Reserved seat...!");
            available -= passenger;
        } else {
            System.out.println ("Seat not available");
        }

    }
}
public class Multithreading_problem {
    public static void main(String args[]) {
        TwelveExample r = new TwelveExample(1);
        Thread t1 = new Thread(r);
        Thread t2 = new Thread(r);
        Thread t3 = new Thread(r);

        t1.setName("Ram");
        t2.setName("Shyam");
        t3.setName("Raju");

        t1.start();
        t2.start();
        t3.start();

    }
}
