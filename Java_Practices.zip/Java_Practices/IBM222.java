import java.util.*;
class IBM222 {
    public static int collision(int pos, int[] speed) {
        // n is the total number of particles
        int n = speed.length;
        int collisions = 0;
        // Track the position of each particle
        int[] particlePositions = new int[n];

        // Initialize particlePositions array
        for (int i = 0; i < n; i++) {
            particlePositions[i] = i;
        }

        // Iterate over time (seconds)
        for (int time = 1; time <= 100; time++) {
            // Update particle positions
            for (int i = 0; i < n; i++) {
                particlePositions[i] += speed[i];
            }

            // Check for collisions
            for (int i = 0; i < n - 1; i++) {
                // if particle i and particle i+1 are at the same position, there's a collision
                if (particlePositions[i] == particlePositions[i + 1]) {
                    // Particle at index pos outpaces all others.
                    // So count the collision only if particle at index pos is involved
                    if (i == pos || i + 1 == pos) {
                        collisions++;
                    }
                    // Break out of the inner loop because a collision is already found
                    break;
                }
            }
        }
        return collisions;
    }
    public static void main(String[] args) {
        int pos = 0;
        int[] speed = {2, 1, };
        int result = collision(pos, speed);
        System.out.println("The number of collisions: " + result); // Output: 1
    }
}

