// comparable-comparator

/*
public class Emp_Comparable implements Comparable<Emp_Comparable> // comparable is an interface

{

        private String name;
        private int phone;
        private int empid;

        @Override
        public int compareTo(Emp_Comparable o) {
            return this.empid-o.empid; // emp id sorting - comparable
        }

        public Emp_Comparable(String name, int phone, int empid){
            this.name = name;
            this.phone = phone;
            this.empid = empid;
        }

    public String getName() {
        return name;
    }

    public int getEmpid() {
        return empid;
    }

    public int getPhone() {
        return phone;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "name='" + name + '\'' +
                ", phone=" + phone +
                ", empid=" + empid +
                '}';
    }

}
*/
// comparator
public class Emp_Comparable  // comparator

{

    private String name;
    private int phone;
    private int empid;

    public Emp_Comparable(String name, int phone, int empid){
        this.name = name;
        this.phone = phone;
        this.empid = empid;
    }

    public String getName() {
        return name;
    }

    public int getEmpid() {
        return empid;
    }

    public int getPhone() {
        return phone;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "name='" + name + '\'' +
                ", phone=" + phone +
                ", empid=" + empid +
                '}';
    }

}

