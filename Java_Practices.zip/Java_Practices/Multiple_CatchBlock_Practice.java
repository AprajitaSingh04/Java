public class Multiple_CatchBlock_Practice {
    public static void main(String args[]) {
        try
        {
            int x = 20, y = 2;
            int z = x/y;
            int a[] = {10, 20, 40, 50};
            System.out.println(a[5]);
            System.out.println(z);
        }
        catch(ArithmeticException e){
            System.out.println("ArithmeticException");
        }
        catch(ArrayIndexOutOfBoundsException e1){
            System.out.println("ArrayIndexOutOfBoundsException");
        }
        catch(Exception e2){
            System.out.println("Exception");
        }
        finally{
            System.out.println("Ended");
        }

        }
}
