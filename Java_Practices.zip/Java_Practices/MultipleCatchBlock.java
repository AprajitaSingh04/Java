public class MultipleCatchBlock {

    public static void main(String args[]) {
        try {
            System.out.println("Arithmetic Try Block started");
            int x = 20, y = 2, z; // try with y =0 ; Exception throws
            z = x / y;
            System.out.println(z);
            System.out.println("Arithmetic Try Block ended");

                int a[] = {10, 20, 30,40};
                System.out.println(a[2]); // a[5] = Exception, a[2] = 30
                System.out.println(" ArrayIndexBound Try Block");

                String str = null; // Appu
                System.out.println(str.toUpperCase());
        //Exceptions are dependent on each other
            }

        catch (ArithmeticException n) {
            System.out.println("ArithmeticException ");

        }

        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException ");

        }
        catch (Exception m) {
            System.out.println("All type Exception handled ");
        // Exception x = new NullPointerException();
        }
        finally
        {
            System.out.println("finally block ");
        }
        System.out.println("Main method ended ");
    }
}
