class Overloading{
    int x; String y; double z;
    /*private Overloading()  // private const and default constructor does not run together. only one will call on running the prog.
    {
        x = 7445; z = 73.65; y = "Coding private";
        // System.out.println(x+ " " +y + " " +z);

    }*/
    Overloading() // Default
    {
        x = 7685; z = 33.65; y = "Coding Constructor";
       // System.out.println(x+ " " +y + " " +z);

    }
    Overloading(int a, String b){
     x = a; y = b;
    }
    Overloading(int a, double c){
    x = a; z = c;
    }
   /* public static void main(String args[]) {
        Overloading r = new Overloading();
        Overloading t = new Overloading(10, "Biggg Boss");
        Overloading q = new Overloading(34, 76.38);
        System.out.println(r.x + " " + r.y + " " + r.z);
        System.out.println(t.x+ " " +t.y);
        System.out.println(q.x+ " " +q.z);
    }*/

}

public class ConstructorOverloading {
    public static void main(String args[]) {
        Overloading r = new Overloading();
        Overloading t = new Overloading(10, "Biggg Boss");
        Overloading q = new Overloading(34, 76.38);
        System.out.println(r.x + " " + r.y + " " + r.z);
        System.out.println(t.x+ " " +t.y);
        System.out.println(q.x+ " " +q.z);
    }
}
