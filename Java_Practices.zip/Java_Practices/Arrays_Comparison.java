
import java.util.Scanner;
import java.util.Arrays;

// 1. ==
// 2. equals()
public class Arrays_Comparison {
    public static void main(String args[]) {
        int a[] = {10, 20, 30, 40,50}; // Array
        int b[] = {10, 20, 30, 40,50};
       // int b[] = {10, 20, 30, 40,50, 60 };
        // equal equal operator
        if(a==b){
            System.out.print("Both are equals ");
        }
        else{
            System.out.print("Both are not equals ");
        }

        // equals()
        if(Arrays.equals(a, b))
        {
            System.out.print("\n Both are equals ");
        }
        else{
            System.out.print("\n Both are not equals ");
        }
    }
}


/*import java.util.Arrays;

public class Arrays_Comparison {
    public static void main(String args[]) {
        int a[] = {10, 20, 30};
        int b[] = {10, 20, 30};

        if (a ==b ){
            System.out.print("Both are equals ");
        }
        else{
            System.out.print(" Both are not equals "); // ref var
        }

        if (Arrays.equals(a,b) ){
            System.out.print("\n Both are equals "); // data
        }
        else{
            System.out.print("\n Both are not equals ");
        }

    }

    }*/
