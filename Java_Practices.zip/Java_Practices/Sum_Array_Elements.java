import java.util.Scanner;

public class Sum_Array_Elements {
    public static void main(String args[]) {
        int a[] = new int[5]; // Array
        int sum = 0;
        Scanner sc = new Scanner(System.in); // Scanner = Runtime value input
        System.out.print("Enter Elements in array: ");
        for (int i = 0; i < a.length; i++) {
            a[i] = sc.nextInt(); // input /// 10, 20, 30, 40, 50

        }
        System.out.print("Array Elements: ");
        for (int i = 0; i < a.length; i++) // i = 0, 1, 2, 3, 4, 5
        {
            System.out.print(a[i] + " "); // print
            sum = a[i] + sum; // 10 + 0 = 10 + 20= 30+ 30 = 60 + 40 = 100 + 50 = 150

        }
            System.out.print("\n Addition of Array elements:  "+sum); // output - 150

        }
    }
