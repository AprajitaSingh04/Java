class Inheritance2 // Super Class
{
    int a, b, c;
    void add()
    {
        a = 10; b =48;
        c = a+b;
        System.out.println("Sum: " +c);

    }
    void sub()
    {
        a = 400; b =78;
        c = a-b;
        System.out.println("Sub: " +c);

    }
}
class Inheritance3 extends Inheritance2 // Sub class 1
{
    void Multi()
    {
        a = 6;
        b = 38;
        c = a * b;
        System.out.println("Multi: " + c);

    }

    void Div()
    {
        a = 50;
        b = 2;
        c = a / b;
        System.out.println("Div: " + c);

    }
}
public class Multilevel_Inheritance extends Inheritance3 // Sub class 2
{
    void Mod()
    {
        a = 80;
        b = 31;
        c = a % b;
        System.out.println("Remainder: " + c);

    }
        public static void main (String args[]){
        Multilevel_Inheritance i = new Multilevel_Inheritance();
        i.add();
        i.sub();
        i.Multi();
        i.Div();
        i.Mod();

    }
    }
