public class Singleton_Samosa {

    private static Singleton_Samosa obj ;
    private Singleton_Samosa(){

    }
// 1.Lazy way of creating single object - Single Thread
   /* public static Singleton_Samosa getSingleton_Samosa()//method
    {
        // object of this class
        if ( obj == null ){
            obj = new Singleton_Samosa();
        }
        return obj;
    }*/


    // Synchronized way - multiple thread
    public static Singleton_Samosa getSingleton_Samosa()//method
    {
        // object of this class
        if (obj == null) {
            synchronized (Singleton_Samosa.class) {
                if (obj == null) {
                obj = new Singleton_Samosa();
            }
        }
    }
        return obj;
    }
    // 2. Eager way of creating singleton object

   /* private static Singleton_Samosa obj2 = new Singleton_Samosa();
    public static Singleton_Samosa getSingleton_Samosa()//method
{
    return obj2;
}*/
    public static void main(String[] args) {
        // Lazy way approach
        Singleton_Samosa samosa = Singleton_Samosa.getSingleton_Samosa();
        System.out.println(samosa.hashCode());
        Singleton_Samosa samosa2 = Singleton_Samosa.getSingleton_Samosa();
        System.out.println(samosa2.hashCode());

// Eager way approach
        /*System.out.println(Singleton_Samosa.getSingleton_Samosa().hashCode());
        System.out.println(Singleton_Samosa.getSingleton_Samosa().hashCode());
*/
    }
}



// non static method requires object
// 1. Private Constructor
//2. obj create with the help of method
// 3. create field to store object is private