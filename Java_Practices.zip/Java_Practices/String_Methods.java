public class String_Methods {
    public static void main(String args[]) {
        String a = "ANKITA"; // String Literal
        String b = "Rahul"; // String Literal

        System.out.println(a.toLowerCase()); // ankita
        System.out.println(b.toUpperCase()); //RAHUL

        System.out.println(b.concat(a)); // rahulANKITA
        System.out.println(b.length()); // 5


        String c = "      Anshu        "; // Anshu
       // String d = "              "; // true
        String d = "Learn"; // false
        System.out.println(c.trim());
        System.out.println(c); //      Anshu
        System.out.println(d.isEmpty());

        System.out.println(b.charAt(2)); // h
        System.out.println(a.indexOf('K')); // 2


        System.out.println(b.equals(a)); // false
        System.out.println(d.replace('r', 'e')); // Leaen

    }
}