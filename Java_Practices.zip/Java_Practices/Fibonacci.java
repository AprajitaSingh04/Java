import java.util.Scanner;

public class Fibonacci {
    public static void main (String args[]) {
        int term, a = 0, b = 1, c; // term = 5
        System.out.print("Enter term: ");
        Scanner sc =new Scanner(System.in);
        term = sc.nextInt();
        for (int i = 1; i <= term; i++) // i = 1, 2, 3 , 4, 5
        {
            System.out.println(a+ "");// 0, 1, 1, 2, 3
            c = a+b; // 0+1 = 1, 2, 3, 5, 8
            a = b; //1, 1, 2, 3, 5
            b = c; // 0, 1, 2, 3, 5, 8


        }



    }
}