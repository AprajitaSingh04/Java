 class Singleton  // WaterJug
 {

    private int waterQuantity = 500;
    private static Singleton object = null;
    private Singleton() // constructor
    {

    }

    public int getSingleton (int quantity){

            waterQuantity = waterQuantity - quantity;
            return quantity;
        }
     public static Singleton getSingleton() // method
     {
         //object of this class
         if (object == null) {
             object = new Singleton();
         }
         return object;
     }

    public static void main(String[] args) {
        Singleton singleton = Singleton.getSingleton();
       // System.out.println(object);
        System.out.println(singleton.hashCode());


    }
}
// non static method requires object
// 1. Private Constructor
 //2. obj create with the help of method
 // 3. create field to store object is private