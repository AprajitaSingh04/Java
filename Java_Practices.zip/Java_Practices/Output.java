import java.util.Scanner;

class Driver {}

  /*  int calculate(int a, int b)
    {
        try{
            return a-b;
        }catch(Exception e){

            return a+b;
        }finally{
            return a*b;
        }
    }
}

public class Output {

            public static void main(String args[])
        {
            Output obj1 = new Output();
            int result = obj1.calculate(2, 3);
            System.out.println("Result: " + result);
        }
        }*/

