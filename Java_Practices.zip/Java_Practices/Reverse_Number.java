import java.util.Scanner;

public class Reverse_Number {
    public static void main(String args[]) {
        int n, rem, s =0; // n = 123
        System.out.print("Enter any number: ");
        Scanner sc =new Scanner(System.in);
        n = sc.nextInt();

        while (n>0){

            rem = n%10; // 123% 10 = 12 = n and rem = 3
            System.out.print(rem);// 3
            n = n/10; // 12

        }


    }
}
