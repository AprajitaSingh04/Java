interface multiple{

    void show(); //public +abstract
}
interface multiple2{

   // void show();
    void disp();
}
public class Multiple_Interface implements multiple2, multiple {
    public void show()
    {
     //   System.out.println("Interface A & B");
        System.out.println("Interface A");
    }
    public void disp()
    {
        System.out.println("Interface B");
    }
    public static void main (String args[]){
        Multiple_Interface i = new Multiple_Interface();
        i.show(); i.disp();
    }
}
