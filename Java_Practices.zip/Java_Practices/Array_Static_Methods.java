
import java.util.Arrays;
import java.util.Scanner;
public class Array_Static_Methods {
    public static void main (String args[]){
        // sorting
        int a [] = new int [5];
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Data in Array for Sorting: ");
        for (int i = 0; i <a.length; i++)
        {
          a[i] =  sc.nextInt();
        }
        Arrays.sort(a);
      //  System.out.println(" ");
        for (int i = 0; i <a.length; i++)
        {
            System.out.println(a[i]+ " ");
        }
        // equals
            int a1 [] = new int [5];
            int b [] = new int [5];
            Scanner sc1 = new Scanner(System.in);
            System.out.println("Enter Data in Array1 for comparison : ");
            for (int i = 0; i <a1.length; i++)
            {
                a1[i] =  sc1.nextInt();
            }
            System.out.println("Enter Data in Array2 for comparison: ");
            for (int i = 0; i <b.length; i++) // 2nd Array
            {
                b[i] =  sc1.nextInt();
            }
           boolean c = Arrays.equals(a1, b );
        System.out.println(" Are both arrays equal: " +c);

       /* int a1 [] = new int [5];
        int b [] = new int [8]; // true
        Scanner sc1 = new Scanner(System.in);
        boolean c = Arrays.equals(a1, b );
        System.out.println(" Are both arrays equal: " +c);*/


        // copyOf
        int d [] = new int [5];
        Scanner sc2 = new Scanner(System.in);
        System.out.println("Enter elements in Array 1 for Copy: ");
        for (int i = 0; i <d.length; i++)
        {
            d[i] =  sc2.nextInt();
        }
        int d2[] = Arrays.copyOf(d,6);
        d2[5] = 100; // d2.length
        System.out.println(" Enter elements in Array 2:");
       // for (int i = 0; i <d.length; i++) {
         for (int i = 0; i <d2.length; i++) {
            System.out.println(d2[i] + " ");
        }

        }
}
