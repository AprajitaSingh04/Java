class NinthExample extends Thread {

    public void run() {

       // System.out.println("isAlive method program..!");

    }
}

public class IsAlive {
    public static void main(String args[]) {

        NinthExample t1 = new NinthExample();
        NinthExample t2 = new NinthExample();

        System.out.println(t1.isAlive()); // false

        t1.start();
        System.out.println(t1.isAlive()); // true

        System.out.println(t2.isAlive()); // false

        t2.start();
        System.out.println(t2.isAlive()); // true
    }
}
