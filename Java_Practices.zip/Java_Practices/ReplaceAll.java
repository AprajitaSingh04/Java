public class ReplaceAll {

    public static void main (String args[]){
        String input = "OneSpace TwoSpace Threespace FourSpace FiveSpace" ;

        String Result =  input.replaceAll("\\s+",  "");

        System.out.println (Result);
    }
}
