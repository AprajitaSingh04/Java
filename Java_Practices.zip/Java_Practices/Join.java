class FifthExample extends Thread{

    public void run(){
        String n = Thread.currentThread().getName();
        for (int i = 1; i<=3; i++) {
            System.out.println(n);
        }
    }
}

public class Join {
    public static void main (String args[]){

        FifthExample t1 = new FifthExample();
        FifthExample t2 = new FifthExample();
        FifthExample t3 = new FifthExample();

        t1.setName("thread 1");
        t2.setName("thread 2");
        t3.setName("thread 3");

      /*  t1.start();

        t2.start();
        try{
            t1.join();
            t2.join();
        }
        catch (Exception e){
            throw new RuntimeException(e);

        }*/

        t2.start();
       try{
            t2.join();
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        t1.start();
        t3.start();

        String n = Thread.currentThread().getName();
        for (int i = 1; i<=3; i++) {
            System.out.println(n);
        }
    }
}
