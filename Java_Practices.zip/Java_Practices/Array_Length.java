import java.util.Scanner;

public class Array_Length {
    public static void main(String args[]) {
        int a[] = new int[3];
        System.out.println("Enter elements in array: ");
        Scanner sc =new Scanner(System.in);
        for (int i = 0 ; i <a.length; i++)
            // for (int i = 0 ; i <5; i++)
        {
            a[i] = sc.nextInt();

        }
        System.out.print("Array Elements: ");
        for (int i = 0 ; i <a.length; i++)
        {
            System.out.println(a[i]+ " ");
        }
        System.out.println("Array length  " +a.length);

    }
}