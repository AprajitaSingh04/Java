public class Method_Overloading {

    /*void add() {
      int  a = 10,b = 48;
      int c = a + b;
      System.out.println("Sum: " + c);

    }*/
    int add() {
        int  a = 10,b = 48;
        int c = a + b;
       return c;

    }
    void add(int x , int y) {
        int c = x+y;
        System.out.println("Sum: " + c);

    }
    void add(int x , double y) {
        double c = x+y;
        System.out.println("Sum: " + c);

    }
    public static void main (String args[]){
        Method_Overloading s = new Method_Overloading();
        int add = s.add();
        s.add(400,500);
        s.add(3987, 56.4);
        System.out.println(add);

    }

}



/*
class Method_Overloading{
    int add(){
        int a=100, b=220;
        int c = a+b;
        //  System.out.println(c);
        return  c;

    }
    void add(int x, int y){
        int c = x+y;
        System.out.println(c);

    }
    void add(int x, double y){
        double c = x+y;
        System.out.println(c);

    }
    public static void main(String args[]){
        Method_Overloading m = new Method_Overloading();
        m.add(10,20);m.add(40,20.00);
        int add = m.add();
        System.out.println(add);

    }


}
*/




