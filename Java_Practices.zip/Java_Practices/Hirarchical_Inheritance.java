
class Hierarchical1 // Super Class
{
    void input() // // protected can accessible
    {
        System.out.println("Enter details:");

    }
}

class Hierarchical2 extends Hierarchical1{
    void show()
    {
        System.out.println("My name is Aprajita");

    }

}
public class Hirarchical_Inheritance extends Hierarchical1{
    void Disp()
    {
        System.out.println("My name is Appu");
    }
        public static void main (String args[]){
        Hirarchical_Inheritance h = new  Hirarchical_Inheritance();
        Hierarchical2 h1 = new Hierarchical2();
        h.input();
        h.Disp();
        h1.input();
        h1.show();

    }

    }




/*
class AB{
    void input(){
        System.out.println("Enter Details:");

    }

}

class BC extends AB{
    void Show(){
        System.out.println("aaaaaaaaa:");

    }
}
class CD extends AB{
    void Disp(){
        System.out.println("bbbbbbbbb:");

    }
}

class Hirarchical_Inheritance{
    public static void main(String args[]){
        BC b = new BC();
        CD c = new CD();
        b.input();b.Show();c.input();c.Disp();

    }

}
*/
