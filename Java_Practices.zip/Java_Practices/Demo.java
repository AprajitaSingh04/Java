class Practice {
    int x; static String y;
    void show(){
        x = 8; y = "Ram";
        System.out.println(x+y); // 7th
    }
    static void m(){

        System.out.println(y+ "yoyo" ); // 2nd static method (order wise)
    }
    Practice( int a, String b){
        this();
        a = x; b = y;
        System.out.println("Hi There" ); // 5th - parametrized
    }
    void Disp(){
        System.out.println("Coding" ); // 6th
    }
    Practice(){

        System.out.println("Hola" );//  default constructor - 4th
    }

  static{
     System.out.println("Hiiiiiiiiii" ); // static block will execute first
 }
    {
        System.out.println("Lalu pagal hai" ); // 3rd - non static
    }

}

    public class Demo {

    public static void main(String args[]) {
      //  Practice.m();
        Practice a1 = new Practice();
     //   Practice a2 = new Practice(); // whenever we create obj constructor will be called
        a1.show();
        a1.Disp();
        a1.m();

    }
}
