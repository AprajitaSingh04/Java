//package java8 ;


//(argument-list) -> { implementation }
public class Lambda_Expression {
    public static void main(String args[]){

     /*   //Traditional approach - without LE
        Drawable_FI d = new Drawable_FI(){
            @Override
            public void draw(int width) {
                System.out.println("Drawing:" +width);
            }
        };
        d. draw(5);*/

        // with Lambda Expression - void method

      /*  Drawable_FI dLambda = (int width) ->
                System.out.println("Drawing from Lambda:" +width);

        dLambda.draw(10);

        Drawable_FI dLambda = (int width) -> {
            System.out.println("Drawing from Lambda:" +width);
        };
        dLambda.draw(15);*/


     // return type - if the method is of int type

        Drawable_FI dLambda = (int width) -> {
            System.out.println("Drawing from Lambda:" + width);
            return width;
        };
        dLambda.draw(10); // 10
        int width = dLambda.draw(20); // 20
        System.out.println("Returned Values:" + width); // 20


}
}
// There is a lot of code involved in traditional coding