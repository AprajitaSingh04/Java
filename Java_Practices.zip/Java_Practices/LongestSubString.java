public class LongestSubString {
    public static void main (String[] args) {
        LongestSubString l = new LongestSubString();
        l.lengthOfLongestSubstring("abcabcbb");
        //.lengthOfLongestSubstring ("abcabcbb");
    }

        private  int lengthOfLongestSubstring(String s){
            char[] ch = s.toCharArray();

            for (int i = 0; i < s.length(); i++) {
                System.out.print(s.charAt(i));
                for (int j = 0; j < s.length(); j++) {
                    System.out.print(s.charAt(j));

                    // boolean unique = true;
                    //   unique = false;
                    break;
                }

            }
            return 0;
        }



}