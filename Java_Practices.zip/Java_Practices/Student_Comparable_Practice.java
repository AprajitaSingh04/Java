import java.util.*;


public class Student_Comparable_Practice implements Comparable<Student_Comparable_Practice>{

        private String name;
        private int age;

        public Student_Comparable_Practice(String name, int age) {
            this.age = age;
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        @Override
        public String toString() {
            //  return "Student {" + "name=' " + name + '\'' + ", age=" +age+ '}';
             return "(" +age + ", " +name+ ")";
        }

        @Override
        public int compareTo(Student_Comparable_Practice other) {
            return this.age - other.age;
        }

        public static void main(String args[]) {
            List <Student_Comparable_Practice> students = new ArrayList<>();
            students.add(new Student_Comparable_Practice("Appu", 24));
            students.add(new Student_Comparable_Practice("Papa", 45));
            students.add(new Student_Comparable_Practice("Mummy", 42));
            students.add(new Student_Comparable_Practice("Popsy", 44));

            Collections.sort(students);
            System.out.println(students);
        }
    }



/*
 public class Student_Comparable_Practice implements Comparable<Student_Comparable_Practice>{
    private String name;
    private int age;
   public Student_Comparable_Practice(String name, int age) {
       this.name = name;
       this.age = age;
   }

    public String getName(){
        return name;
       }
    public int getAge(){
        return age;
    }
    @Override
    public int compareTo(Student_Comparable_Practice other){
      return this.age - other.age;
    }
    @Override
    public String toString(){
       return name + "("  + age + ")";

    }
    public static void main(String args[]) {

       List<Student_Comparable_Practice> names = new ArrayList<>();

       names.add(new Student_Comparable_Practice("Appu", 24));
        names.add(new Student_Comparable_Practice("zebra", 2));
        names.add(new Student_Comparable_Practice("bicky", 4));
        names.add(new Student_Comparable_Practice("daku", 14));
        names.add(new Student_Comparable_Practice("book", 421));
        names.add(new Student_Comparable_Practice("yak", 204));

        Collections.sort(names);
        System.out.println(names);


    }
    }*/
