
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class JavaCollection_Hashmap {
    public static void main(String[] args) {

        HashMap<String, String> Name = new HashMap<String, String>(); // ArrayList object
        Name.put("Key1", "Aprajita");
        Name.put(null, "first_null"); // null as a key consider one key
        Name.put(null, "Second_null");// null as a key consider one key
        Name.put("Key2", "Alia");
        Name.put("Key3", null);

        System.out.println("Map size before Iteration:" +Name.size());


      /*  Iterator<String> itr = Name.keySet().iterator();
        while (itr.hasNext()){
            itr.next();
            Name.remove("key2");
        }*/
        Iterator<Map.Entry<String, String>>
                itr = Name.entrySet().iterator();
        while (itr.hasNext()){
           Map.Entry<String, String>
                   entry =  itr.next();
           if ("key1".equals(entry.getKey())){
               itr.remove();
           }

        }
        System.out.println("Map size after Iteration:" +Name.size());
    }
}