
public class Static_VS_Instance {
    static int a; static int b; int c;
    static
    {
        a = 10;  b = 30;
        System.out.println(a+" "+b); // static block
    }

    {
        a = 400;  b = 700; c = 90;
        System.out.println(a+" "+b+" " +c); // Instance block
    }
    Static_VS_Instance (){
        System.out.println("learn Java"); // default const

    }
    /*static
    {
        System.out.println("learn Coding"); // Instance block
    }*/
    // Instance
    {
        System.out.println("learn Instance"); // Instance block
    }
    public static void main(String args[]) {
        Static_VS_Instance diff = new Static_VS_Instance();

    }
}