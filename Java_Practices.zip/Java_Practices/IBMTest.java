import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class IBMTest {
;   /* public int countCollisions(int[] speed, int pos) {
        int n = speed.length;
        int collisions = 0;
        // Check if the particle at pos will collide with particles to its right
        for (int i = pos + 1; i < n; i++) {
            if (speed[i] < speed[pos]) {
                collisions++;
            } else if (speed[i] == speed[pos]) {
                collisions++;
                break;
            } else {
                break;
            }
        }
        // Check if the particle at pos will collide with particles to its left
        for (int i = pos - 1; i >= 0; i--) {
            if (speed[i] < speed[pos]) {
                collisions++;
            } else if (speed[i] == speed[pos]) {
                collisions++;
                break;
            } else {
                break;
            }
        }
        return collisions;
    }
    public static void main(String[] args) {
        IBMTest sol = new IBMTest();
        int[] speed = {2, 1};
        int pos = 0;
        int collisions = sol.countCollisions(speed, pos);
        System.out.println("Number of collisions: " + collisions);
    }
    }*/

/*
        public static int collision(int pos, int[] speed) {
            // number of particles
            int n = speed.length;
            // initialize collision count to 0
            int count = 0;
            // iterate through all particles from pos+1 onwards
            for (int i = pos + 1; i < n; i++) {
                // calculate the time for the particles to collide
                double time = (double) (i - pos) / (speed[pos] - speed[i]);
                // if the time is positive and a whole number, it means they collide at a whole second
                if (time > 0 && time % 1 == 0) {
                    // increase collision count
                    count++;
                    // if the current particle has a lower speed than the particle at pos, it will never collide with any other particle again
                    // so we can break the loop
                    if (speed[i] < speed[pos]) {
                        break;
                    }
                }
            }
            // return the collision count
            return count;
        }
        public static void main(String[] args) {
            // test cases
            int pos1 = 0;
            int[] speed1 = {2, 1};
            System.out.println(collision(pos1, speed1)); // 1
            int pos2 = 0;
            int[] speed2 = {2, 2};
            System.out.println(collision(pos2, speed2)); // 0
            int pos3 = 1;
            int[] speed3 = {1, 2, 1, 3, 2};
            System.out.println(collision(pos3, speed3)); // 1
        }
        }*/

       /* public static int collision(int pos, List<Integer> speed) {
            int n = speed.size();
            int collisions = 0;
            for (int i = pos + 1; i < n; i++) {
                int distance = i - pos;
                int time = distance / speed.get(pos);
                if (speed.get(i) < speed.get(pos)) {
                    int time1 = distance / speed.get(i);
                    if (time == time1) {
                        collisions++;
                    }
                }
            }
            return collisions;
        }

        public static void main(String[] args) {
            List<Integer> speed = Arrays.asList(2, 1);
            int pos = 0;
            int collisions = collision(pos, speed);
            System.out.println(collisions); // Output: 1
        }
        }*/

      /*  public static int collision(int pos, List<Integer> speed) {
            // Write your code here
            int collisions = 0;
            int currentPos = pos;
            int currentSpeed = speed.get(pos);
            for (int i = pos + 1; i < speed.size(); i++) {
                if (speed.get(i) < currentSpeed) {
                    collisions++;
                    break;
                }
            }
            return collisions;
        }
    public static void main(String[] args) {
        List<Integer> speed = Arrays.asList(2, 1);
        int pos = 0;
        int collisions = collision(pos, speed);
        System.out.println(collisions); // Output: 1
    }
    }*/


   /* public static int collision(int pos, List<Integer> speed) {
        int n = speed.size(); int collisions = 0;
        for (int i = pos + 1; i < n; i++)
        { int distance = i - pos; int time = distance / speed.get(pos);
            if (speed.get(i) < speed.get(pos))
            { int time1 = distance / speed.get(i);
                if (time == time1) { collisions++;
                }
            }
        }
        return collisions;
    }

        public static void main(String[] args) {
        List<Integer> speed = Arrays.asList(2, 1);
        int pos = 0;
        int collisions = collision(pos, speed);
        System.out.println(collisions); // Output: 1
    }
}
*/




        public static int collision(int pos, List<Integer> speed) {
            int n = speed.size();
            int collisions = 0;
            for (int i = pos + 1; i < n; i++) {
                int distance = i - pos;
                int time = distance / speed.get(pos);
                if (speed.get(i) < speed.get(pos)) {
                    int time1 = distance / speed.get(i);
                    if (time == time1) {
                        collisions++;
                    }
                }
            }
            return collisions;
        }

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the number of particles: ");
            int n = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            System.out.print("Enter the speeds of the particles separated by spaces: ");
            String[] speedStr = scanner.nextLine().split(" ");
            List<Integer> speed = Arrays.asList(new Integer[speedStr.length]);
            for (int i = 0; i < speedStr.length; i++) {
                speed.set(i, Integer.parseInt(speedStr[i]));
            }
            System.out.print("Enter the starting position: ");
            int pos = scanner.nextInt();
            int collisions = collision(pos, speed);
            System.out.println("Number of collisions: " + collisions);
        }
    }



