class Default {
    int a;
    String b;
    boolean c;

    Default() // Default
    {
        a = 10;
        b = "Aprajita";
        c = true;
    }

    void Disp() {
        System.out.println(a + " " + b + " " + c);
    }
}

    class Parametrized {
        int p; int q; boolean r;
        Parametrized( int k, int l){
           // p = k; q = l;
            System.out.println(k+ " " +l);
        }
        Parametrized( int k, int m, boolean n){
            p = k; q = m; r = n;
        }
        void Show() {
            System.out.println(p+ " " +q+ " " +r);
        }


    }



        public class ConstructorCoding {
            public static void main (String args[]){
                Default e = new Default(); // Default
                e.Disp(); // Default
               // e.Show();// compilation err
                Parametrized e1 = new Parametrized(1020,4500);// parametrized
                Parametrized e2 = new Parametrized(2300,6700, true);// parametrized
             // e.Disp(); // Default
             // e1.Show(); // parametrized
                e2.Show(); // parametrized



            }
}
