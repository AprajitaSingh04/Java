import java.util.ArrayList;

public class JavaCollection_ArrayList {
    public static void main(String[] args) {
// Pre-defined ArrayList class
        // pre-defined method
        ArrayList<String> Name = new ArrayList<String>(); // ArrayList object
        Name.add("Aprajita");
        Name.add("Bhavesh");
        Name.add("Alia");
        // add
        System.out.println(Name);// Array print
        Name.add("Anish"); // Add element in the end
        System.out.println(Name); // print

        Name.add(1, "Rohit"); // Add element in the 1st position
        System.out.println(Name); // print
        Name.add(0, "Virat"); // Add element in the 0th position
        System.out.println(Name); // print


        // remove
        System.out.println(Name);// Array print
        Name.remove(2); // remove element in the 2nd position
        System.out.println(Name); // print

        // set - replace
        System.out.println(Name);// Array print
        Name.set(3, "Ankita" ); // replace element in the 3rd position in the new element
        System.out.println(Name); // print
        //get method
        System.out.println(Name.get(1)); // print Aprajita only in the Array

        // clear - delete
        System.out.println(Name);// Array print
        Name.clear(); // Delete the whole Array
        System.out.println(Name); // print
    }
}
// clear method is used to Delete the whole Array
// remove method is used to delete the element in specified position