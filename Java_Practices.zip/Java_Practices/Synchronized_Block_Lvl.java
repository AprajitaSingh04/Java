class msg {
    public void show(String name) //t1 and t2 : synchronized method
    {
        synchronized (this){
        ;;;;;;;;;;;;;
        for (int i = 1; i <= 3; i++) {
            System.out.println("How are you " +name);
            ;;;;;;;;;;;;;;
        }
        }
    }
}

class Ourthread extends Thread{
    msg m; String name;
    Ourthread(msg m, String name){
        this.m = m;
        this.name = name;
    }
    public void run(){
        m.show(name);

    }
}

public class Synchronized_Block_Lvl {
    public static void main (String args[]){
        msg m = new msg(); //m has a lock

        Ourthread t1 = new Ourthread(m, "akhilesh");
        Ourthread t2 = new Ourthread(m, "ankush");
        t1.start();
        t2.start();
    }

}
