public class String_Comparison {

    /*public static void main(String args[]) {
        String a = "Lion"; // String Literal
        String b = "Lion"; // true || Dog, LION // ASCII Value comparison
       // String b = new String ("Lion"); // False
        if(a ==b)
        {

            System.out.print("True");
        }
        else {
            System.out.print("False");
        }
    }
}*/
// obj reference var - equal equal method
// equals method - content
    public static void main(String args[]) {
        String str = null;
      //  System.out.print(str.length()); // exception
        String a = "Lion"; // String Literal
        String b = new String ("Lion"); // new keyword // Tiger
       // if(a ==b) // False (equal equal operator)
       if(a.equals(b)) // True (equals method)
        {
            System.out.print("True");
        }
        else {
            System.out.print("False");
        }
    }
}