package protected_package;

import Apru_UserDefined_Package.User_defined_package;
// protected
/*
public class protected_class extends User_defined_package {
    public static void main(String args[]) {

        protected_class p = new protected_class();
        p.show();
    }
}*/



//public

public class protected_class extends User_defined_package {
    public static void main(String args[]) {

        User_defined_package p = new User_defined_package();
        p.show();
    }
}

