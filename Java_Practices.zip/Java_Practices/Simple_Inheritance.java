class Inheritance // Super Class
{
    protected int roll, marks; // protected can accessible
    // int roll, marks;
    String name;
    /*void input(){
        System.out.println("Enter details:");

    }*/
    protected void input() // // protected can accessible
    {
        System.out.println("Enter details:");

    }
    /*private void input(){
        System.out.println("Enter details:");

    }*/ // private can't access
}
public class Simple_Inheritance extends Inheritance // sub class
{
    void disp(){
        roll = 1; marks = 100; name = "Aprajita";
        System.out.println(name+" "+roll+" " +marks);
    }
    public static void main(String args[]) {
        Simple_Inheritance i = new Simple_Inheritance();
        i.input(); i.disp();

    }
}