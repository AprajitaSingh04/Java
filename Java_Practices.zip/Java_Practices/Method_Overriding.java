class shape {
    void draw() {
        System.out.println("can't say shape type");

    }
}
class square extends shape {

   void draw() {
       super.draw();
       System.out.println("Square shape");

        }
    /*void draw2() {
        System.out.println("Square shape");

    }*/

}
public class Method_Overriding {
    public static void main (String args[]){
        shape s = new square();
        s.draw();
    }
}
