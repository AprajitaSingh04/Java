public class Multiple_trycatch {
    public static void main(String args[]) {
        try {
            System.out.println("Try Block started");
            int x = 20, y = 0, z; // try with y =2
            z = x / y;
            System.out.println(z);
            System.out.println("Try Block ended");
        }
        catch (ArithmeticException n) {
            System.out.println("Exception Occur ");

        }
        try {
            int a[] = {10, 20, 30,40};
            System.out.println(a[5]); // a[5] = Exception, a[2] = 30
           // System.out.println("Try Block ended");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Beyomd the Array limit ");

        }
        finally
        {
            System.out.println("finally block ");
        }
        System.out.println("Main method ended ");
    }
}
