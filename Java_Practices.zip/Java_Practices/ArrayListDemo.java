import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {

    public static void main(String [] args){
        //Declare arrayList
        // ArrayList al = new ArrayList(); // Heterogeneous
        // ArrayList <Integer> al = new ArrayList <Integer>(); // Homogeneous
        // ArrayList <String> al = new ArrayList <String>(); // Homogeneous
        // List al = new ArrayList();
        ArrayList al = new ArrayList(); // Heterogeneous

      // Add new elements to the ArrayList
        al.add(100);
        al.add("Welcome");
        al.add(15.5);
        al.add('A');
        al.add(true);

        System.out.println(al); // [100, Welcome, 15.5, A, true]

        // size()
        System.out.println(" Number of elements in array list: "+al.size());// Number of elements in array list: 5
       // remove
        al.remove(1) ; // here 1 is index
        al.remove("welcome");
        System.out.println("After removing elements from array list: "+al);// [100, 15.5, A, true]
        // insert a new element
        // add (index, object)
        al.add(2, "Python");
        System.out.println("After insertion: "+al);// [100, 15.5, A, true] // [100, 15.5, Python, A, true]
        // retrieve specific element
        System.out.println(al.get(2));// Python, here 2 is index of element/object

        // change element/replace
        al.set(2, "C#");
        System.out.println("After replacing element:" +al); // [100, 15.5, C#, A, true]

        // search - contains()
        al.contains("C#"); // Returns true/false
        System.out.println(al.contains("C#")); // true
        System.out.println(al.contains("C++")); // false

        // isEmpty()
        System.out.println(al.isEmpty()); // false

        // 1) for loop
        System.out.println("Reading element using for loop........"); //

        for (int i = 0; i<al.size(); i++){
            System.out.println (al.get(i));
        }

        // 2) for..each loop
        System.out.println("Reading element using for...each loop........"); //
        for (Object e:al){
            System.out.println (e);

        }
        // 3) iterator() method
        System.out.println("Reading element using iterator method........"); //
        Iterator it = al.iterator();
        while(it.hasNext()){
            System.out.println (it.next());

        }


    }



}
