
//Multithreading Solution = Synchronization
//Bus = TwelveExample
class ThirteeenExample implements Runnable {
    int available = 2, passenger ; // available = 3; seat will be booked for all 3. if avl = 2 seat will be booked for 2.
    ThirteeenExample (int passenger){
        this.passenger = passenger;  //passenger = 1
    }
    public synchronized void run() // t1 or t2 or t3
    {
        String name = Thread.currentThread().getName();
        if (available >= passenger) // 1>=1
        {
            System.out.println (name+" Reserved seat...!");
            available -= passenger;
        } else {
            System.out.println ("Seat not available");
        }

    }
}
public class Synchronization {
    public static void main(String args[]) {
        ThirteeenExample r = new ThirteeenExample(1); //by default 1
        Thread t1 = new Thread(r);
        Thread t2 = new Thread(r);
        Thread t3 = new Thread(r);

        t1.setName("Ram");
        t2.setName("Shyam");
        t3.setName("Raju");

        t1.start();
        t2.start();
        t3.start();

    }
}
