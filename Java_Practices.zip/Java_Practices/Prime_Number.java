import java.util.Scanner;

public class Prime_Number {
    public static void main(String args[]) {
        int n, count=0; // n = 3
        System.out.println("Enter any Number: ");
        Scanner sc =new Scanner(System.in);
        n = sc.nextInt();
       for (int i = 1; i <= n ; i++) // i = 1
       {
           if (n % i == 0) // 3%1 = 0 = rem
           {
               count++; // count = 1
           }
       }
           if (count == 2){
               System.out.println("Prime number ");
           }
           else {
               System.out.println("Not a Prime number ");
           }



    }
}