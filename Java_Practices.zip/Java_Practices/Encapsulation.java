class Encapsul{

    private int value; // data hiding

    public void setValue(int x) // data abstraction
    {
       value = x;
    }
    public int getValue(){
        return value;
    }
}
public class Encapsulation {
    public static void main (String args[]) {
        Encapsul e = new Encapsul();
        e.setValue(100);
        System.out.println(e.getValue());
    }
    }
