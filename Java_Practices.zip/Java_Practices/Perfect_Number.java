
/*Perfect Number Program*/

// input number 6 ----> 1 2 3 4 5
// 6 is div by 1,2,3---> 1+2+3 = 6

import java.util.Scanner;

public class Perfect_Number {

    public static void main(String args[]) {
        int n, sum = 0 ;
        System.out.println("Enter any Number: ");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt(); // 6

        for ( int i =1; i<n ; i++) // i = 1 started from i = 1, n = 5<6
        {
            if (n%i == 0) // 6 % 1 == 0
            {
                sum = sum+i; // 0+1= 1

            }
        }
            if (n == sum)
                System.out.println("Perfect Number ");

            else
                System.out.println("Not Perfect Number ");
    }
}
