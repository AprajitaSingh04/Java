public interface Interface_Default {

    void a1(); // public+abstract
    void a2(); // public+abstract
    default void a3() // after jdk1.8 interface is not 100% abstraction because it supports static and default method
    {
    System.out.println("may or may not override in implementing classes");
    }
    static void a4() // after jdk1.8 interface is not 100% abstraction because it supports static and default method
    {
        System.out.println("may or may not override in implementing classes - static");
    }

}

class B implements Interface_Default {
    @Override
    public void a1() {
        System.out.println(" Class B a1()");
    }

    @Override
    public void a2() {
        System.out.println(" Class B a2()");
    }
    @Override
    public void a3() // public is greater in priority compare to default method ( lower method should have high priority)
    {
        System.out.println("override in implementing class B");
    }
}
class C implements Interface_Default {
    @Override
    public void a1() {
        System.out.println(" Class C a1()");
    }

    @Override
    public void a2() {
        System.out.println(" Class C a2()");
    }
}
class D implements Interface_Default {
    @Override
    public void a1() {
        System.out.println(" Class D a1()");
    }

    @Override
    public void a2() {
        System.out.println(" Class D a2()");
    }
}
class Main {
    public static void main(String args[]) {
        B b = new B();
        b.a1();b.a2();b.a3();
        C c = new C();
        c.a1();c.a2();c.a3();
       // Interface_Default d = new D();
        Interface_Default d = new D();
        d.a1();d.a2();d.a3(); Interface_Default.a4();

    }
}
// Without affecting other classes it may or may not override in implementing classes