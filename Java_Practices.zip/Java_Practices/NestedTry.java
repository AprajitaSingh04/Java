public class NestedTry {
    public static void main(String args[]) {
        try {
            try {
                int a[] = {10, 20, 30, 40};
                System.out.println(a[5]); // a[5] = Exception, a[2] = 30
                System.out.println(" ArrayIndexBound Try Block");
            }
            catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("ArrayIndexOutOfBoundsException ");

                }

            System.out.println("Arithmetic Try Block started");
            int x = 20, y = 0, z; // try with y =0 ; Exception throws
            z = x / y;
            System.out.println(z);
            System.out.println("Arithmetic Try Block ended");
        }
        catch (ArithmeticException n) {
            System.out.println("Arithmetic Exception ");

        }
        finally
        {
            System.out.println("finally block ");
        }
        System.out.println("Main method ended ");
    }
}
