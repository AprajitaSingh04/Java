public class StringExample_practice {
    public static void main(String[] args) {
        String first = "Football";
        String second = "Football";
        //String second =  new String ("Football");
        //String second =  new "Football";

        //System.out.println(second.equals(first)); // true
        if (first == second) {
          System.out.println(true); // true
           // System.out.println(second.equals(first)); // true
        } else {
            System.out.println(false);
        }

        if (first.equals(second)) {
            System.out.println(true); // true
        } else {
            System.out.println(false);

        }
        String first1 = new String ("Footballer");
        String second1 = new String ("Footballer");
        //System.out.println(second.equals(first)); // true
        if (first1 == second1) {
            System.out.println(true);
        } else {
            System.out.println(false); // false
        }

        if (first1.equals(second1)) {
            System.out.println(true); // true
        } else {
            System.out.println(false);

        }
    }
}





