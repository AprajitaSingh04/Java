public class TryCatchFinally {
    public static void main(String args[]) {
        try {
            System.out.println("Try Block started");
            int x = 20, y = 0, z; // try with y =2
            z = x / y;
            System.out.println(z);
            System.out.println("Try Block ended");

        }
        catch (ArithmeticException n) {
            /*int a = 20, b = 0, c; // try with y =2
            c = a / b;
            System.out.println(c);*/
            System.out.println("Exception Occur ");
          //  System.exit(0);
             }
        finally
        {
            System.out.println("finally block ");
        }
        System.out.println("Main method ended ");
    }
}
