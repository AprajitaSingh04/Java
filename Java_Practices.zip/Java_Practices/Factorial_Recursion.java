import java.util.Scanner;

public class Factorial_Recursion {
    public static void main(String args[]) {
        int n; //3
        System.out.print("Enter any number: ");
        Scanner sc =new Scanner(System.in);
        n = sc.nextInt();
        Factorial_Recursion f = new Factorial_Recursion();
        int result = f.fact(n);//fact(3) = 6
        System.out.print("factorial of a given num: " +result);
    }
    int fact (int n){
        if (n ==1)
            return 1;
        else
            return n*fact(n-1);//3* fact(2) = 3*2 = 6

    }
   /* int fact (int n) // n = 2
   {
        if (n ==1)
            return 1;
        else
            return n*fact(n-1); // 2*fact(1) = 2

    }*/
    /* int fact (int n) // n = 1
   {
        if (n ==1)
            return 1;
        else
            return n*fact(n-1);//3* fact(2) // 1*fact(0)

    }*/
}
