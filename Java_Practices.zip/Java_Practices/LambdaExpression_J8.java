public class LambdaExpression_J8 {
    public static void main(String args[]) {


        Runnable r1 = new Runnable() {
            @Override
            public void run() {
                System.out.println("Hello from Before J8 Lambda Runnable");
            }
        };

       // Lambda
        Runnable r2 = () -> System.out.println("Hello from after J8 Lambda Runnable ");

        r1.run();
        r2.run();

//***********************************************************************

        Drawable_FI d = new Drawable_FI() {
            @Override
            public int draw(int width) {
                System.out.println("Hello from Before J8 Lambda Drawable");
                return width;
            }
        };
        System.out.println("Returned Values:" +d.draw(20)); // 20

        // Lambda
        Drawable_FI dLambda =(int width) -> {
            System.out.println("Hello from after J8 Lambda Drawable");
            return width;
        };
        System.out.println("Returned Values:" +d.draw(60)); // 20

    }
}

