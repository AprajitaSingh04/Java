// Collection(I) - 1. List(I) 2. Set (I) 3. queue - 1. Priorityqueue (C) 2. Linkedlist (c)
// Queue(I) - 1. Dequeue (I) 2. BlockingQueue(I) 3. BlockingDequeue(I)
// List(I) - LinkedList
// A chain interface which is derived from root collection interface.
// When u need to prefer queue concept? - A Group of elements which are prior to processing. It follows FIFO Concept. example - mobile numbers

// queue - 1.  Linkedlist(C) - Insertion order is preserved, Duplication are allowed, Heterogeneous data allowed.
// 2. Priorityqueue (c) - Insertion order is preserved, Duplication are allowed, Heterogeneous data not allowed (only homogeneous allowed).

// There are 2 end. 1. Head - to remove elements. . 2. tail - to add element.

// 1. add() method - To add element in the queue. if it is successful it will return TRUE otherwise it will return Exception.
// 2. offer() method - To add element in the queue. If the element in the Queue is successful it will return TRUE otherwise it will return FALSE.
// 3. element() - If the Queue is empty and try to fetch the header element then it will return EXCEPTION.
// 4. Peek () method - If the Queue is empty and try to fetch the header element then it will return NULL.
// 5. remove() method - This method is used to return and remove the element. If the queue is empty it will return EXCEPTION.
// 6. poll() method - This method is used to return and remove the element. If the Queue is empty it will return NULL.

import java.util.Iterator;
import java.util.PriorityQueue;

public class QueueDemo {

    public static void main(String[] args) {
        PriorityQueue q = new PriorityQueue();
        // Adding elements add() offer()
        q.add("A");
        q.add("B");
        q.add("C");
        q.offer("C");
     //   q.offer(100); // not allowed in queue because Heterogeneous data is not allowed

        System.out.println(q); // [A, B, C, C] // insertion order preserved & duplicates allowed

        // get head element    element()    peek()
      //  System.out.println(q.element()); // [] - A returns Head element, if empty returns NoSuchElementException
     //   System.out.println(q.peek()); // [] null - A returns Head element, if empty null

        // Return  & Remove element from queue    remove() poll()

       // System.out.println(q.remove()); // A
        // System.out.println(q); // [B, C, C]
        // [] - A returns Head element, if empty returns NoSuchElementException


      // System.out.println(q.poll()); // A
      // System.out.println(q); // [B, C, C]
        // [] null - A returns Head element, if empty null

        Iterator itr = q.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next()) ;
            //A
            //B
            //C
            //C
        }

        for (Object ele: q )
        {
            System.out.println(ele);
            // A
            //B
            //C
            //C
        }
    }
    }
