import java.util.Arrays;
// toString() asList() deepToString()
public class Array_ClassMethods {
    public static void main(String args[]) {
        int b [] = {50, 60, 70};
        String a[] = {"Learn" , "Coding ", "Keypoints", "Education"};
        System.out.println("To String method " +Arrays.toString(a)); // toString - Array variable accepts as a parameter.// Single - D
        System.out.println("To String method " +Arrays.toString(b));

        System.out.println("As List method " +Arrays.asList(a)); // Single - D
        System.out.println("As List method " +Arrays.asList(b));


        int arr[][] = {{10,20},{30, 40 }};
        System.out.println("Deep to String method " +Arrays.deepToString(arr)); // 2-D Array accepts. // multi - D array

    }
}

// toString method works better with Integer value whereas asList method print the value as a ref for Int value.