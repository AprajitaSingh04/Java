class EleventhExample extends Thread{

    public void run(){
        System.out.println(Thread.currentThread().getName());
        System.out.println(Thread.currentThread().getPriority());
        
    }
}

public class SetPriority_GetPriority {
    public static void main (String args[]){

        EleventhExample t1 = new EleventhExample();
        EleventhExample t2 = new EleventhExample();
        EleventhExample t3 = new EleventhExample();

        t1.setName("thread 1");
        t2.setName("thread 2");
        t3.setName("thread 3");

        t1.setPriority(2);
        t2.setPriority(6);
        t3.setPriority(7); //  being highest execute first

        t1.start();
        t2.start();
        t3.start();

    }
}

