import java.util.Scanner;

public class String_palindrome {
    public static void main (String args[]) {
        String n;
        System.out.println("Enter a word: ");
        Scanner sc =new Scanner(System.in);
        n = sc.nextLine();
        String rev = "";
       for (int i = 0; i < n.length(); i ++) {
           rev = n.charAt(i) + rev;
       }
          if (n.equalsIgnoreCase(rev)){
         //if (n.equals(rev)){
            System.out.println("Palindrome  ");
          }
          else {
              System.out.println("Not a Palindrome  ");
          }


    }
}
