public class Throw_Throws {
    public static void main(String args[]) throws InterruptedException {
   // public static void main(String args[]) {
            // Throw Exaample
     /*  //   System.out.println(10/0);
        throw new ArithmeticException("/ by zero");*/
// Throws Example
        for (int i = 1; i < 10; i++) {
            System.out.println(i);
            Thread.sleep(1000);
       /* try{
            System.out.println(i);
            Thread.sleep(1000);
        }
        catch (InterruptedException e){
            System.out.println(e);
        }*/

        }
    }

}
