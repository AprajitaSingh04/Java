class EigthExample extends Thread{

    public void run(){
        String n = Thread.currentThread().getName();
        for (int i = 1; i<=3; i++) {
            System.out.println(n);
        }
    }
}

public class Stop {
    public static void main (String args[]){

        EigthExample t1 = new EigthExample();
        EigthExample t2 = new EigthExample();
        EigthExample t3 = new EigthExample();

        t1.setName("thread 1");
        t2.setName("thread 2");
        t3.setName("thread 3");

        t1.start();
        t2.start();
        t3.start();
        t2.stop();
        }
    }


