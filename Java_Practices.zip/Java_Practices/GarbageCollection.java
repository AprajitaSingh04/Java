public class GarbageCollection {
    private GarbageCollection gc;

    public static void main(String[] args) {
        GarbageCollection gc; // use in 3rd approach
        // 1st Approach
        String S1 = "Some String" ;
        S1 = null; // GC
        System.out.println(S1);


        // 2nd Approach
        String S2 = "To Garbage collect" ;
        String S3 = "Another object";
        System.out.println(S2);  // S1 not yet eligible for GC
        S2 = S3; // now S1 is eligible for GC

        // 3rd approach - Island of Isolation
        GarbageCollection gc1 = new GarbageCollection();
        GarbageCollection gc2 = new GarbageCollection();
        gc1.gc = gc2;
        gc2.gc = gc1;
        gc1 = null; // eligible for GC
        gc2 = null; // eligible for GC

    }
    public void finalize(){
        System.out.println("Finalize");
    }
}