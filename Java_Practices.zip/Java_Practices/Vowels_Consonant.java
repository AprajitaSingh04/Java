import java.util.Scanner;

public class Vowels_Consonant {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a single alphabet: ");
        char alphabet = sc.next().charAt(0);

        boolean isVowel = false;

        if ( alphabet == 'a' || alphabet == 'A'
                || alphabet == 'e' || alphabet == 'E'
                || alphabet == 'i' || alphabet == 'I'
                || alphabet == 'o' || alphabet == 'O'
                || alphabet == 'u' || alphabet == 'U') {
            isVowel = true;
        }
        if(isVowel){
            System.out.println(alphabet+ " is vowel ");
        }
        else{
            System.out.println(alphabet+ " is consonant ");
        }
    }
}