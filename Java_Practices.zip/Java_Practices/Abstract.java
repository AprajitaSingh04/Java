abstract class Animal{

    Animal(){
        System.out.println("All Animals...!!!!"); // const
    }
   public abstract void sound();
  //  public void A1(){} // non abstract method

}
class Dog extends Animal{
    Dog(){
        super();
    }
    public  void sound(){
        System.out.println("Dog is barking");
    }
}
class Lion extends Animal{
    Lion(){
        super();
    }
    public  void sound(){
        System.out.println("Lion is roar");
    }
}
public class Abstract {
    public static void main (String args[]) {
      //  Animal a = new Dog();
        Dog d = new Dog();
        Lion l = new Lion();
        d.sound();l.sound();
    }
    }
