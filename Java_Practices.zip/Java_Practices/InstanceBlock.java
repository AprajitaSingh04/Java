
class Instance_Example{
    int a, b;
     /*void show(){
        a = 70; b = 60;
        System.out.println(a+ " " +b); // method

    }*/
     static void show(){

         System.out.println("Static"); // method

     }
    Instance_Example (){
        a = 30; b = 20;
        System.out.println(a+ " " +b); // Constructor
    }
    {
        a = 100; b = 50;
        System.out.println(a+ " " +b); // Instance block
    }


}
public class InstanceBlock {

    public static void main(String args[]) {
        Instance_Example.show();
        Instance_Example s = new Instance_Example();
       // s.show();
    }
}

//  1. Instance, 2. Constructor, 3. method - order wise execution
// First execute static block then instance then const then method.
// if Static block call will call in the end then it will execute at end if it will call first it withh execute first.