
class Instance_Example{
    int a, b;
  /*   void show(){
        a = 70; b = 60;
        System.out.println(a+ " " +b); // method

    }*/
     static void show(){

         System.out.println("Static"); // method

     }
    Instance_Example (){
        a = 30; b = 20;
        System.out.println(a+ " " +b); // Constructor
    }
    {
        a = 100; b = 50;
        System.out.println(a+ " " +b); // Instance block
    }


}
public class InstanceBlock {

    public static void main(String args[]) {
        Instance_Example.show();
        Instance_Example s = new Instance_Example();
       // s.show();
    }
}

//  1. Instance, 2. Constructor, 3. method - order wise execution - if static method will call end it will execute at end if it will call first it will execute first.
// First execute static block then instance then const then method. and static method - order wise
// if Static method will call in the end then it will execute at end if it will call first it will execute first.
//static method does not deals with object it deals with class so we can call acc to our preference.
// Normal method call with object
// instance block always gets executed with object







 /*lass ABC{
     int a,b ;
     void show(){
       a = 10; b = 20;
         System.out.println(a+ " " +b);
     }
     static void Disp(){

         System.out.println("Learn Java");
     }

     ABC(){
        a = 30; b = 40;
         System.out.println(a+ " " +b);
     }
     {
         a = 70; b = 90;
         System.out.println(a+ " " +b);
     }
     static{

         System.out.println("Learn Coding");
     }

}
public class InstanceBlock{
    public static void main(String args[]) {
        //ABC.Disp();
        ABC abc = new ABC();
        abc.show();
        ABC.Disp();
    }
    }

*/