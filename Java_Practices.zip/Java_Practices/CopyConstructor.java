class Copy {
    int a; String b; boolean c;
    Copy()
    {
        a = 10; b = "Learn Coding"; c = true;
        System.out.println(a+ " " +b);
    }
    Copy(Copy ref)
    {
        a = ref.a; b = ref.b;
        System.out.println(a+ " " +b);
    }
    /* Copy(int a, String b)
    {
        a = 10; b = "Learn Coding"; c = true;
        System.out.println(a+ " " +b);
    }
    Copy(Copy ref_parametrized)
    {
        a = ref_parametrized.a; b = ref_parametrized.b;
        System.out.println(a+ " " +b);
    }*/
}
public class CopyConstructor {
    public static void main (String args[]){
        Copy e = new Copy(); // copy
        Copy e1 = new Copy(e); // copy ref
     //   Copy c = new Copy(9876, "copy constructor"); // copy
     //   Copy c1 = new Copy(c); // copy ref_parametrized
    }
}
