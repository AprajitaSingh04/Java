import java.util.Scanner;

public class Pattern_Inverted {
    public static void main (String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("How many rows you want this in pattern: ");
        int rows = sc.nextInt();
        int count =1;
        System.out.println("Here is your pattern....!!");
        for (int i = 1; i<=rows;i++){
            for (int j = rows; j >= i ; j--) {
                System.out.print(" ");
            }
            for (int k = 1; k<= i ; k++) {
               // System.out.print(i);
               // System.out.print(k+ " ");
                System.out.print(count+ " ");
                count++;
            }
                System.out.println();

            }
    }
}


