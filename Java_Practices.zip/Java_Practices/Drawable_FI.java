//package java8;
@FunctionalInterface
public interface Drawable_FI {

       // void draw(int width);


        // resturn statement
        int draw(int width);



}
