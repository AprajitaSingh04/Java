class SeventhExample1 extends Thread{

    public void run(){
        String name = Thread.currentThread().getName();
        for (int i = 1; i<=3; i++) {
            System.out.println(name);
            Thread.yield();
        }
    }
}
class SeventhExample2 extends Thread{

    public void run(){
        String n = Thread.currentThread().getName();
        for (int i = 1; i<=3; i++) {
            System.out.println(n);
        }
    }
}
public class Yield {
    public static void main(String args[]) {

        SeventhExample1 t1 = new SeventhExample1();
        SeventhExample2 t2 = new SeventhExample2();

        t1.start();
        t2.start();
    }
}