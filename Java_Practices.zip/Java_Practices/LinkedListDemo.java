import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListDemo {
    public static void main(String[] args) {
        //Declare LinkedList
        // LinkedList l = new LinkedList(); // heterogeneous

        //  LinkedList <Integer> l = new LinkedList<Integer>(); // homogeneous
        //  LinkedList <String> l2 = new LinkedList<String>(); // homogeneous

        LinkedList l = new LinkedList(); // heterogeneous

        // Add elements into LinkedList
        l.add(100);
        l.add("Welcome");
        l.add(15.5);
        l.add('A');
        l.add(true);
        l.add(null);

        System.out.println(l); // [100, Welcome, 15.5, A, true, null]
        System.out.println(l.size()); // 6
        //remove
        l.remove(3); // index
        System.out.println("After removing, new list: " +l); // [100, Welcome, 15.5, true, null]
       // l.remove ('A'); // value not allowed, index only allowed

        // inserting/adding element in the middle of linked list
        l.add (3, "Java");
        System.out.println("After inserting, new list: " +l); // After inserting, new list: [100, Welcome, 15.5, Java, true, null]

        // retrieving value/object
        System.out.println(l.get(3));//Java

        // change the value/object
        l.set(5, "X");
        System.out.println("After changing the value: " +l);//[100, Welcome, 15.5, Java, true, X]

        // contains
        System.out.println(l.contains("Java")); // true
        System.out.println(l.contains("Python")); // false

       //isEmpty
        System.out.println(l.isEmpty());//false

        // Reading elements from LL using for Loop

        for ( int i = 0; i<l.size();i++)
        {
            System.out.println(l.get(i));

        }
// Reading elements from LL using for each Loop

        for (Object e:l)
        {
            System.out.println(e);
        }
        // iterator() method

        Iterator it = l.iterator();
        while (it.hasNext()){
            System.out.println(it.next());

        }



    }
}