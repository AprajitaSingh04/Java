import java.util.Comparator;

public class NameComparator implements Comparator<Emp_Comparable>{
    @Override
    public int compare(Emp_Comparable o1, Emp_Comparable o2) {
        return o1.getName().compareTo(o2.getName());
    }
}
// CompareTo function is used to compare 2 strings