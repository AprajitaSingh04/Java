import java.util.Comparator;

public class NameComparator implements Comparator<Emp_Comparable>{
    @Override
    public int compare(Emp_Comparable o1, Emp_Comparable o2) {
        return o1.getName().compareTo(o2.getName());
    }



/*public class NameComparator implements Comparator<Student_Comparable_Practice>{

    @Override
    public int compare(Student_Comparable_Practice s1, Student_Comparable_Practice s2) {
        return s1.getName().compareTo(s2.getName());
    }*/
}
// CompareTo function is used to compare 2 strings