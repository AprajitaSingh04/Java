import java.util.HashSet;
import java.util.LinkedHashSet;

// Hashset - Duplicates are not allowed, insertion order is not preserved, hashtable used, initial size - 16 and Load factor is 0.75
// LinkedHashset - Duplicates are allowed, insertion order is preserved, hashtable and Linkedlist used, initial size - 16 and Load factor is 0.75
// Both uses set interfaces
//
public class LinkedHashsetDemo {

    public static void main(String[] args) {
        // LinkedHashSet<Integer> lset = new LinkedHashSet<Integer>();
        LinkedHashSet lset = new LinkedHashSet(); // [100, 200, 300, 400, 500]
        // HashSet lset = new HashSet(); // [400, 100, 500, 200, 300] // insertion order is not preserved

        lset.add(100);
        lset.add(200);
        lset.add(300);
        lset.add(400);
        lset.add(500);
        System.out.println(lset); // [400, 100, 500, 200, 300]


    }
    }
