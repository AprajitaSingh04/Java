class Bank1 extends Thread {
    static int bal=5000;
    static int withdraw;
    Bank1 (int withdraw){
        this.withdraw = withdraw;
    }

    public static synchronized void withdraw() {
        String n = Thread.currentThread().getName();
        if (withdraw<=bal){
            System.out.println(n +" withdrawn money");
            bal = bal - withdraw;
        }
        else{
            System.out.println("Insufficient money");
        }
    }

    @Override
    public void run() {
        withdraw();
    }
}
public class Static_synchronization //Bank1 has one lock
{
    public static void main (String args[]){

        Bank1 obj = new Bank1(5000);
        Thread t1 = new Thread(obj);
        Thread t2 = new Thread(obj);

        t1.setName("Raju");
        t2.setName("Sunita");

        Bank1 obj2 = new Bank1(5000);
        Thread t3 = new Thread(obj2);
        Thread t4 = new Thread(obj2);

        t3.setName("Rahul");
        t4.setName("Anita");

        t1.start();
        t2.start();
        t3.start();
        t4.start();
    }
}

