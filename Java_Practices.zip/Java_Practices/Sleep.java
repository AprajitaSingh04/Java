class FourthExample extends Thread {

    public void run() {
        String n = Thread.currentThread().getName();
        try {
            for (int i = 1; i <= 3; i++) {
                System.out.println(n);
                Thread.sleep(2000);
            }
        } catch (InterruptedException e)
        {
           // throw new RuntimeException(e);
        }
    }
}

public class Sleep {
    public static void main (String args[]){

        FourthExample t1 = new FourthExample();
        FourthExample t2 = new FourthExample();
        FourthExample t3 = new FourthExample();

        t1.setName("thread 1");
        t2.setName("thread 2");
        t3.setName("thread 3");

        t1.start();
        t2.start();
        t3.start();
        }
    }


