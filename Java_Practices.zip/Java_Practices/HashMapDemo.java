// Collection - List (I), Set(I), Queue(I)

// Map (I) - HashMap (I), HashTable(I)

// Map interface is not a child interface of collection interface it is completely independent of collection and no where related to collection interface
// Map - 2 important classes. - 1. HashMap 2. HashTable
// Map interface is implemented by Hashmap and hashtable classes.

// When we will go for Map interface? - if you want to represent group of elements and objects as a key and value pairs then we will go for Map interface.
// one dataset (key, value - pairs) - Eid (101, 102, 103 )and Ename (David, Smith, John)
// Entry - A combination of key and values.
// every key is a object and every value is a object

// Map is a collection of entries - Duplicate keys are not allowed but duplicate values are allowed.
// Map is a collection of entries where we can store the the elements in the form of keys values pairs. every key is a unique but we can add duplicate values.



// HashMap (class) - whenever search operation. Searching will be faster.
// 1. underlying Data structure is hashtable.
// 2. Insertion order is not preserved.
// 3. Duplicate keys are not allowed
// 4. Duplicate values are allowed.
// 5. Null keys allowed only once
// 6. Multiple null values

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

// put() method - one (key, value) - To add new pair in the hashmap.
// putAll() method - multiple (key, value) - is a method by which we can add multiple new pair in the hashmap.
// get (key) - get is the method by which we can get the element by passing a key. - To return the value (to retrieve an element)
// remove(key) - remove is a method by which we can remove an entire key by using a key
// contains(key) - To verify if the key is present or not.. it will return true or false
// contains (value) - To verify if the value is present or not. if yes, it will return true or false
// isEmpty() - To verify the map is empty or not.
// size() - To
// clear() - it will clear entire hashmap
// set - keyset() - whatever keys are there in the map. all the list of keys will be returned by keyset (Set).
// collection - values() -
// set - entryset() - entryset is a method which will return all the entry from the hashmap individually.
// getkey() - get the key
// getvalues() - get the values
// setvalue - update the key
//
public class HashMapDemo {
    public static void main(String[] args) {
        //  HashMap m = new HashMap();
         HashMap <Integer, String> m = new HashMap<Integer,String>();
       // HashMap m = new HashMap();
        m.put(101, "John");
        m.put(102, "David");
        m.put(103, "Scott");
        m.put(104, "Marry");
        m.put(105, "Tye");
        m.put(103, "X");
        m.put(106, "David");

        System.out.println(m); // {101=John, 102=David, 103=X, 104=Marry, 105=Tye, 106=David}
        System.out.println(m.get(105)); // Tye
        m.remove(106); // remove pair from hashmap
        System.out.println(m); // {101=John, 102=David, 103=David, 104=Marry, 105=Tye}
        System.out.println(m.containsKey(101)); // true
        System.out.println(m.containsKey(106)); // false

        System.out.println(m.containsValue("Marry"));//true
        System.out.println(m.containsValue("Y"));// false

        System.out.println(m.isEmpty()); // false

        System.out.println(m.keySet()); // returns all the keys as set //[101, 102, 103, 104, 105]
        for(Object i: m.keySet()) // all the keys as individual object
        {
            System.out.println(i);
        }
        // 101
        // 102
        // 103
        // 104
        // 105
        System.out.println(m.values()); // returns all the values as collection // [John, David, X, Marry, Tye]
        for(Object i: m.values()) // all the keys as individual object
        {
            System.out.println(i);
        }
        //John
        //David
        //X
        // Marry
        // Tye

        System.out.println(m.keySet()); // returns all the keys as set //[101, 102, 103, 104, 105]
       // looping statement keys and values together
        for(Object i: m.values()) // all the value as individual object
        {
            System.out.println(i);
        }
        for(Object i: m.keySet()) // all the keys as individual object
        {
            System.out.println(i+ "    " +m.get(i));
        }
      /*  O/p:
        101    John
        102    David
        103    X
        104    Marry
        105    Tye*/

        // Entry method - Entry set is related to entry interface
        // Entry is a sub interface of map
        System.out.println(m.entrySet()); //Returns all the entries as Set. [101=John, 102=David, 103=X, 104=Marry, 105=Tye]

        for(Map.Entry entry: m.entrySet()) // it will return all the entries(which contains keys & values)) from hashmap
        {
            System.out.println(entry.getKey()+ "   "+entry.getValue());
        }
        //first need to specify the type integer of hashmap
       /* 101   John
        102   David
        103   X
        104   Marry
        105   Tye*/
        //  System.out.println(entry.getKey()+ "   "+entry.getValue()); &             System.out.println(i+ "    " +m.get(i));
        // Both will work the same

        // iterator - All the keys & values
        Set s =  m.entrySet();
        Iterator itr = s.iterator();// itr = keys+values

        while (itr.hasNext()){
           Map.Entry entry = (Map.Entry) itr.next(); // 101x entry
            System.out.println(entry.getKey()+ "  " +entry.getValue());
        }
        /*101  John
        102  David
        103  X
        104  Marry
        105  Tye*/

    }
    }
