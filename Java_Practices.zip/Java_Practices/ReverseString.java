import java.util.Scanner;
public class ReverseString {


    public static void main(String[] args) {
        //1. using StringBuffer
        StringBuffer r = new StringBuffer("Coding Example");
        System.out.println(r.reverse()); // reverse method  is used to reverse the string of String buffer and string builder class

        //2. using StringBuffer
        StringBuilder ref = new StringBuilder("Coding Example");
        System.out.println(ref.reverse()); // Reverse method is used to reverse the string of String buffer and string builder class

        //3. using String
       String str = "Coding Example";

        //Pointers.
        int i = 0, j = str.length()-1;

        //Result character array to store the reversed string.
        char[] revString = new char[j+1];

        //Looping and reversing the string.
        while(i < j){
            revString[j] = str.charAt(i);
            revString[i] = str.charAt(j);
            i++;
            j--;
        }
        //Printing the reversed String.
       System.out.println("Reversed String = " + String.valueOf(revString));



        /*String s = "Coding Example";
        int i=0, j =s.length()-1;
        char[] revstring = new char[j+1];
        while (i < j){
            revstring[j] = s.charAt(i);
            revstring[i] = s.charAt(j);
            i++;
            j--;
        }
        System.out.println("Reversed = " +  String.valueOf(revstring));*/

        // 4. Using String


        /*String str1 = "coding Example"; // str1.length = 14
        String str2 = ""; // e, l
*/
        System.out.print("Enter any number: ");
        String str2 = "";
        String str1;
        Scanner sc = new Scanner(System.in);
        str1 = sc.nextLine();

        for (int m = str1.length() -1; m>=0; m--) // str1.length = 14-1=13-1=12
        {
          str2 =str2+str1.charAt(m); // 13 index = e/12 index = l

        }
        System.out.println(str2);

    }
}
