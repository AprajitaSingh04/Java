import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

public class Remove_Duplicates {
    public static void main(String args[]) {
        ArrayList<Integer> listwithDuplicates = new ArrayList<>();
        listwithDuplicates.add(1);
        listwithDuplicates.add(2);
        listwithDuplicates.add(2);
        listwithDuplicates.add(3);
        listwithDuplicates.add(3);
        listwithDuplicates.add(4);

        Set<Integer> settwithDuplicates = new LinkedHashSet<>(listwithDuplicates);
       // ArrayList<Integer> listwithDuplicates = new ArrayList<>(settwithDuplicates);
        listwithDuplicates = new ArrayList<>(settwithDuplicates);

        System.out.println(listwithDuplicates);



    }
}
