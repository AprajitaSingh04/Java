public class Static_VS_NonStatic {
    int a = 10;
    static int b = 20;
    public static void main(String args[]) {
        Static_VS_NonStatic obj = new Static_VS_NonStatic();
        obj.Disp(); // Static method // before show
        Static_VS_NonStatic.show(); // static method work without obj, only class will require

      //  obj.Disp(); // Static method // after show
      //  Static_VS_NonStatic.Disp(); // Non static will not work, only work with object
        // obj.show();
    }
    static void show(){
        System.out.println("show " +b);

    }
    void Disp (){
        System.out.println("Disp "+a+" "+b);

    }
}
