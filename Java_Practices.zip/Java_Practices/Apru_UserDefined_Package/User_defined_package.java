package Apru_UserDefined_Package;
// private package
  /* public class User_defined_package {
    private void show() {
         System.out.println("User Defined private package");

     }

     public static void main(String args[]) {
         User_defined_package p = new User_defined_package();
         p.show();
     }*/

  //Default package
 /*class User_defined_package {
      void show() {
         System.out.println("User Defined default package");

     }
 }
class App{
    public static void main(String args[]) {
        User_defined_package p = new User_defined_package();
        p.show();
    }
}*/
/*
// protected package
class App {
   protected void show() {
        System.out.println("User Defined protected package");

    }
    }
public class User_defined_package extends App{
    public static void main(String args[]) {
        User_defined_package p = new User_defined_package();
        p.show();
    }
}*/

// public  package
class App {
    public void show() {
        System.out.println("User Defined public package");

    }
}
public class User_defined_package extends App{
    public static void main(String args[]) {
        User_defined_package p = new User_defined_package();
        p.show();
    }
}


/*
The main difference between the default and protected access modifiers is the scope of accessibility.

The default access modifier allows access within the same class and within any class in the same package.
The protected access modifier allows access within the same class and within any subclass of that class,
regardless of the package.
In other words, the protected access modifier provides access to subclasses even if they are in a
different package, whereas the default access modifier only provides access to classes within the same
package.

Here's an example to illustrate the difference:


// Package: com.example.package1
public class MyClass {
    int x = 10; // // default access modifier
    protected int y = 20; // protected

}

// Package: com.example.package2
public class MySubClass extends MyClass {
        void myMethod() { // protected access modifier
        System.out.println("This is a protected method:" +y); // protected = accessible
        // System.out.println("This is a default method: " +x); // not accessible

    }

    }


*/
