import java.util.Scanner;

public interface Interface {
    void input(); // public +abstract
    void output();  // public +abstract
}
class Raju implements Interface{
       String name; double sal;
    public void input(){
        Scanner r = new Scanner(System.in);
        System.out.println("Enter Username: ");
        name = r.nextLine();
        System.out.println("Enter Salary: ");
        sal = r.nextDouble();
    }

        public void output()
       {
            System.out.println(name+" " +sal);
        }
        public static void main (String args[]){
            Interface i = new Raju();
            i.input();i.output();
        }


}