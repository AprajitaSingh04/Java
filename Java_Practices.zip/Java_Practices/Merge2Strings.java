

public class Merge2Strings {
    public static void main(String[] args)
    {
        //System.out.println(result(m, n));

     //   Merge2Strings result =  null;
     //   result.mergeAlternately();
    }

    public String mergeAlternately( String word1, String word2){
        int m = word1.length();
        int n = word2.length();
        int i =0;
        String result1 ="";
        StringBuilder result = new StringBuilder("Rajput Aprajita");
      //  System.out.println(result.mergeAlternately(m,n));
        //for (int i = 0; i < Math.max(m, n) i++)//
            while (i<m||i<n)
        {
            if (i<m){
                result.append(word1.charAt(i));
            }
            if (i<n){
                result.append(word2.charAt(i));
                i++;
            }

        }
         return result.toString();

    }
}