import javax.xml.namespace.QName;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;


// comparable - comparator
public class Comparator_Comparable {
    public static void main(String args[]) {
        ArrayList<Emp_Comparable> emps = new ArrayList<>();
        emps.add(new Emp_Comparable("Aprajita", 98765432, 45));
        emps.add(new Emp_Comparable("Bhavesh", 123456, 12));
        emps.add(new Emp_Comparable("Elvish", 7865438, 10));

       // Comparable
        /* System.out.println(emps); // not sorted
        Collections.sort(emps);
        //Comparable - single level sorting
        System.out.println(emps); // Id wise sorting with the help of comparable
        */


        // comparator
        System.out.println(emps); // not sorted
        Collections.sort(emps, new IdComparator()); // comparator
        System.out.println(emps); // sorting w.r.t name
        ArrayList<Emp_Comparable> emps1 = new ArrayList<>();
        Collections.sort(emps1, new NameComparator());
        System.out.println(emps1);
        // multiple sorting logic name wise and id wise.

    }
}
// comparator - 1. multiple logic sorting, changes in diff class
// 2. compare method - it take 2 parameters of 2 obj to compare
//3. Java. Util

//comparable - 1. single level sorting either by name or id or phone, changes in the same class
//2. compareTo function - it takes single parameter. it compare same obj of the given obj.
// 3. Java. Lang
