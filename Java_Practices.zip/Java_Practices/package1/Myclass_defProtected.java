package package1;

// The main difference between the default and protected access modifiers is the scope of accessibility.
public class Myclass_defProtected {
    int x = 10; // // default access modifier
    protected int y = 20; // protected

}