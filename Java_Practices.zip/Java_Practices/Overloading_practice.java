
public class Overloading_practice {

    public int findarea(int l, int b) {
        int var1;
        var1 = l * b;
        return var1;
    }

    public int findarea(int l, int b, int h) {
        int var2;
        var2 = l * b * h;
        return var2;

    }

    public static void main(String[] args) {
        Overloading_practice o = new Overloading_practice();
        int findarea1 = o.findarea(12,20);
        int findarea2 = o.findarea(10,20,30);
        System.out.println(findarea1);
        System.out.println(findarea2);

    }

}

/*
public class Overloading_practice {
     int findarea( int l, int b){
        int var1 = l*b;
        return var1;
    }
     int findarea( int l, int b, int h){
        int var2 = l*b*h;
        return var2;
    }
    public static void main(String[] args) {
        Overloading_practice o = new Overloading_practice();
        int find1 = o.findarea(10, 220);
        int find2 = o.findarea(5, 10, 18);
        System.out.println(find1);
        System.out.println(find2);
    }
    }*/
