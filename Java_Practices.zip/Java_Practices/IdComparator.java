import java.util.Comparator;

public class IdComparator implements Comparator<Emp_Comparable> {
    @Override
    public int compare(Emp_Comparable o1, Emp_Comparable o2) {
        return o1.getEmpid()- o2.getEmpid();
    }
}
