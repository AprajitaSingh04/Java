public class Print_Array_Elements {
    public static void main(String args[]) {
    int a [] = new int [3];
    a[0] = 10;
        a[0] = 10;
        a[1] = 20;
        a[2] = 30;

       /* for (int i = 0; i< 3 ; i++){
            System.out.println(a[i]+ " ");

        }*/
        for (int b: a) // For Each loop - better than for loop
        {
            System.out.println(b+ " ");

        }



    }



}
