
import java.util.LinkedList;

public class JavaCollection_LinkedList {
    public static void main(String[] args) {
// Pre-defined ArrayList class
        // pre-defined method
        LinkedList<String> Name = new LinkedList<String>(); // LinkedList object
        Name.add("Aprajita");
        Name.add("Chhoti");
        Name.add("Alia");

        // add
        System.out.println(Name);//  print
        Name.addFirst("Anish"); // Add element in the begin
        Name.addLast( "Rohit"); // Add element in the end
        System.out.println(Name); // print
        Name.add(2, "Virat"); // Add element in the middle - 2nd position
        System.out.println(Name); // print

        // remove - delete
        Name.remove(); // remove element from the begening - 0th position removed
        System.out.println(Name); // print
        Name.remove(2); // remove element in the 2nd postion
        System.out.println(Name); // print

        Name.removeFirst(); // remove element from the begening - 0th position removed
        System.out.println(Name); // print
        Name.removeLast(); // remove element in the end
        System.out.println(Name); // print

        for (String str: Name) // for each loop
        {
            System.out.println(str); // one element in a row

        }


    }
}

// Arraylist - Array creation and array type memory creation and element stored in the form of Array
// LinkedList - Stores the element in the form of doubly linkedlist in the computer memory and that is in doubly linkedlist*/

/*
import java.util.LinkedList;

public class JavaCollection_LinkedList {
    public static void main(String[] args) {

        LinkedList <String> Name = new LinkedList<String>();
        //add
        Name.add("Virat");
        Name.add("Chhoti");
        Name.add("Shipra");
        System.out.println(Name);

        Name.addFirst("Appu");
        System.out.println(Name);

        Name.addLast("Amir");
        System.out.println(Name);


        Name.add(0, "Dhoni");
        System.out.println(Name);

        //remove
       */
/* Name.remove(2);
        System.out.println(Name);
        Name.remove();
        System.out.println(Name);
        Name.removeAll(Name);
        System.out.println(Name);*//*



        Name.removeFirst();
        System.out.println(Name);
        Name.removeLast();
        System.out.println(Name);

        for (String str: Name){
            System.out.println(str);
        }



    }
    }*/
