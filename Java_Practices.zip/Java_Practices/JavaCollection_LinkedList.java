import java.util.LinkedList;

public class JavaCollection_LinkedList {
    public static void main(String[] args) {
// Pre-defined ArrayList class
        // pre-defined method
        LinkedList<String> Name = new LinkedList<String>(); // LinkedList object
        Name.add("Aprajita");
        Name.add("Bhavesh");
        Name.add("Alia");

        // add
        System.out.println(Name);//  print
        Name.addFirst("Anish"); // Add element in the begin
        Name.addLast( "Rohit"); // Add element in the end
        System.out.println(Name); // print
        Name.add(2, "Virat"); // Add element in the middle - 2nd position
        System.out.println(Name); // print

        // remove - delete
        Name.remove(); // remove element from the begening - 0th position removed
        System.out.println(Name); // print
        Name.remove(2); // remove element in the 2nd postion
        System.out.println(Name); // print

        Name.removeFirst(); // remove element from the begening - 0th position removed
        System.out.println(Name); // print
        Name.removeLast(); // remove element in the end
        System.out.println(Name); // print

        for (String str: Name) // for each loop
        {
            System.out.println(str); // one element in a row

        }


    }
}

// Arraylist - Array creation and array type memory creation and element stored in the form of Array
// LinkedList - Stores the element in the form of doubly linkedlist in the computer memory and that is and doubly linkedlist