class TenthExample extends Thread{

    public void run(){
        try {
                for (int i = 1; i<=3; i++) {
                    System.out.println("t1 thread running");
                    Thread.sleep(1000); // waiting
            }

        } catch (InterruptedException e) {
            System.out.println("t1 thread terminated...!"); //Interrupt
        }
    }
}

/*class TenthExample2 extends Thread {

    public void run() {
        try {
            for (int i = 1; i <= 3; i++) {
                System.out.println("t2 thread running...!"); //Interrupt

            }
        }
        catch(Exception i){
            System.out.println("t2 thread terminated...!"); //Interrupt

        }
    }
}*/

public class Interrupt {
    public static void main(String args[]) {

        TenthExample t1 = new TenthExample();
      //  TenthExample2 t2 = new TenthExample2();

        t1.start();
        t1.interrupt(); //interrupt method always use with sleep method.

     //   t2.start();
    }
}