package DSA_Geeks4Geeks;

import java.util.HashMap;

public class SubArrayWithGivenSum {
    static int subArraySum(int arr[], int n, int sum){
    int currSum = 0; int start =0, end =-1;

        HashMap<Integer, Integer> map = new HashMap<>();

        for(int i =0; i < n; i++){
            currSum+= arr[i];

            // Check if current sum equals the desired sum
            if(currSum - sum ==0){
                start = 0; end =i;
                break;
            }

            // If the map contains (currSum - sum), that means we've found a subarray
            if(map.containsKey(currSum - sum)){
                start = map.get(currSum - sum) +1;
                end =i;
                break;
            }
            // Store the current sum and index in the map
            map.put(currSum, i);
        }
        // Check if the subarray was found
        if (end == -1){
            System.out.println("No SubArray found");
            return -1;  // Return -1 if no subarray was found
        }
        else{
            System.out.println("Sum found between indexes: " +start+ " , " +end);
            return end - start + 1; // Return the length of the subarray

        }
    }

    public static void main(String[] args) {
        SubArrayWithGivenSum obj = new SubArrayWithGivenSum();
        int arr[] = {10, 2, -2, -20, 10};
        int sum = -10;
        subArraySum(arr, arr.length, sum);
    }
}
