package DSA_Geeks4Geeks;

import java.util.Arrays;

public class validAnagram {
    public static void main(String[] args) {
        String a = "anagram";String b = "nagaram";
        System.out.println(isAnagram(a, b));

    }
// 1st Approach
    public static boolean isAnagram(String a, String b){

       if (a.length() != b.length()){
            return  false;
        }

        char[] ch = a.toCharArray();
        char[] sh = b.toCharArray();

        Arrays.sort(ch);
        Arrays.sort(sh);

        if(Arrays.equals(ch,sh)){
            return true;
        }
      return false;
    }
    }
    // 2nd Approach

/*
    public static boolean isAnagram(String a, String b){
        int s = a.length();
        int t = b.length();

       if(s!=t){
           return false;
       }
       int count[] = new int[26];
       for(int i = 0; i<a.length();i++){
           count[a.charAt(i) - 'a']++;
       }
        for(int i = 0; i<b.length();i++){
            count[b.charAt(i) - 'a']--;
        }
        for(int i = 0; i<count.length;i++){
              if(count[i]!=0){
                  return false;
              }
        }
        return true;
    }
}*/
