package DSA_Geeks4Geeks;
public class SortedArrayOrNot {

    static boolean arraySortedOrNot(int n, int[] arr){

        for(int i =1; i<arr.length ; i++){
            if(arr[i]< arr[i-1]){
                return false;
            }
        }
        return true;
    }



    public static void main(String[] args) {
        int arr[] = {10, 2, -2, -20, 10}; // {10, 20, 30, 40, 50}
        int n = 5;
        System.out.println(arraySortedOrNot(n, arr));
    }
}
