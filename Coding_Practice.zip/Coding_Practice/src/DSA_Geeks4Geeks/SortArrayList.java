package DSA_Geeks4Geeks;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/*Sorting an ArrayList of Wrapper Class objects.

1. Ascending Order
2. Descending Order
Sorting an ArrayList of User-defined objects.

1. Comparable
2. Comparator*/

public class SortArrayList {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList();
        list.add("India");
        list.add("Pak");
        list.add("USA");
        list.add("China");
        list.add("Bhutan");
        list.add("Australia");
        list.add("Nepal");

        System.out.println("Before Sorting : " +list);

        // Ascending Order
        Collections.sort(list);
        System.out.println("After Sorting : " +list);

        // Descending Order
        Collections.sort(list, Collections.reverseOrder());
        System.out.println("After Sorting in reversed order: " +list);


    }
}
// Implements comparable interface into custom class

/*class Car implements Comparable<Car> {
    int ModalNo;
    String name;
    int stock;

    // Parameterized constructor of the class
    Car(int ModalNo, String name, int stock)
    {
        this.ModalNo = ModalNo;
        this.name = name;
        this.stock = stock;
    }

    // Override the compareTo method
    public int compareTo(Car car)
    {
        if (stock == car.stock)
            return 0;
        else if (stock > car.stock)
            return 1;
        else
            return -1;
    }
}

// Main driver method
class SortArrayList {

    // Main driver method
    public static void main(String[] args)
    {
        // Create the ArrayList object
        ArrayList<Car> c = new ArrayList<Car>();
        c.add(new Car(2018, "Kia", 20));
        c.add(new Car(2020, "MG", 13));
        c.add(new Car(2013, "creta", 10));
        c.add(new Car(2015, "BMW", 50));
        c.add(new Car(2017, "Audi", 45));

        // Call the sort function
        Collections.sort(c);

        // Iterate over ArrayList using for each loop
        for (Car car : c) {

            // Print the sorted ArrayList
            System.out.println(car.ModalNo + " " + car.name + " " + car.stock);
        }
    }
}*/

// Java Program to Sort an ArrayList using Comparator
/*

class Car {
    int ModalNo;
    String name;
    int stock;

    // Parameterized constructor
    Car(int ModalNo, String name, int stock)
    {
        this.ModalNo = ModalNo;
        this.name = name;
        this.stock = stock;
    }
}

// Class 2: Child class
// creates the comparator for comparing stock value
class StockComparator implements Comparator<Car> {

    // Function to compare
    public int compare(Car c1, Car c2)
    {
        if (c1.stock == c2.stock)
            return 0;
        else if (c1.stock > c2.stock)
            return 1;
        else
            return -1;
    }
}

class SortArrayList {

    // Main driver method
    public static void main(String[] args)
    {
        // Create the ArrayList object
        ArrayList<Car> c = new ArrayList<Car>();
        c.add(new Car(2018, "Kia", 20));
        c.add(new Car(2020, "MG", 13));
        c.add(new Car(2013, "creta", 10));
        c.add(new Car(2015, "BMW", 50));
        c.add(new Car(2017, "Audi", 45));

        // Call the sort function
        Collections.sort(c, new StockComparator());

        // For each loop to iterate
        for (Car car : c) {

            // Print the sorted ArrayList
            System.out.println(car.stock + " " + car.name + " " + car.ModalNo);
        }
    }
}
*/
