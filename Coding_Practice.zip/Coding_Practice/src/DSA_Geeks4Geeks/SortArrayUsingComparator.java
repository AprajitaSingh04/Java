package DSA_Geeks4Geeks;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

// For String
/*public class SortArrayUsingComparator implements Comparator<String> {

    @Override
    public int compare(String s1, String s2){
        return s1.length() - s2.length(); // ascending
       // return s2.length() - s1.length(); // descending order

    }

    public static void main(String[] args) {
        List<String> names = Arrays.asList("Jan" , "Tommy", "Jon", "Adam");

        names.sort(new SortArrayUsingComparator());
        System.out.println(names);

    }
}*/

// For Integer
public class SortArrayUsingComparator implements Comparator<Integer> {

    @Override
    public int compare(Integer i1, Integer i2){
       // return i1 -i2; // ascending
        return i2 - i1; // descending order

    }

    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(4, 2 , 5, 1 , 3);

        numbers.sort(new SortArrayUsingComparator());
        System.out.println(numbers);

    }
}