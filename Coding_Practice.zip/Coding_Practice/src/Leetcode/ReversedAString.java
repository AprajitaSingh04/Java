package Leetcode;
public class ReversedAString {

    public static void main(String[] args) {
        String str ="INTERVIEW";

       //1st Approach
       /* char [] ch = str.toCharArray();

        for (int i= ch.length - 1; i>= 0; i--){
            System.out.println(ch[i]);
        //  results += ch[i]; if the static method
        }*/

        // 2nd Approach

        StringBuilder revStr= new StringBuilder(str);
        System.out.println(revStr.reverse());
        // return reverse().toString(); if the static method


       // 3rd Approach
        /*String results ="";
        for (int i= str.length() - 1; i>= 0; i--){
           System.out.println(str.charAt(i));
         //  results += str.charAt(i); if the static method

        }*/

        // 4th approach
       /* String rev ="";
        for (int i=0;i< str.length() ; i++) {
            System.out.println(str.charAt(i));
            rev += str.charAt(i); // //if the static method
        }*/

    }
    }

    // String doesn't have reversed function, StringBuffer/StringBuilder have reversed function so it will reverse the string
