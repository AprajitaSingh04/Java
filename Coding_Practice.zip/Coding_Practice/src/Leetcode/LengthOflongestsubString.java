package Leetcode;

import java.util.ArrayList;
import java.lang.Math;
import java.util.List;

// leetcode 3
// sliding window approach
// 2 pointer
public class LengthOflongestsubString {
        public static void main (String[]args){

            String s ="abcdabcbb"; // pwwkew// abcabcbb // bbbbb
            int start = 0, end = 0, max_len = 0;
            List<Character> list = new ArrayList<>();

          while (end<s.length()){
              if(!list.contains(s.charAt(end))){
                  list.add(s.charAt(end));
                  end++;
                  max_len = Math.max(max_len, list.size());
              }
              else{
                  list.remove(Character.valueOf(s.charAt(start)));
                  start++;
              }
          }
          System.out.println("Max length is : " +max_len);

        }
    }
