package Leetcode;
// leetcode 28
public class IndexOffirstOccurence {
    public static void main(String[] args) {
        String heystack = "sadbutsad" ;
        String needle = "sad";
       // String needle = "dog";
        System.out.println(strStr(heystack,needle ));


    }

    public static int strStr(String heystack, String needle){
        return heystack.indexOf(needle);

    }
    }
