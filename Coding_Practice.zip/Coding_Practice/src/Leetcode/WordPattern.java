package Leetcode;
import java.util.HashMap;
// leetcode 290
public class WordPattern {
    public static void main(String[] args) {
        String pattern = "abba";
        String s = "dog cat cat dog";  // Notice the space after each word, no commas
        System.out.println(wordPattern(pattern, s));
    }

    public static boolean wordPattern(String pattern, String s) {
        String[] arr = s.split(" ");  // Split by spaces
        if (arr.length != pattern.length()) {
            return false;
        }

        HashMap<Character, String> map = new HashMap<>();
        for (int i = 0; i < pattern.length(); i++) {
            char ch = pattern.charAt(i);
            String word = arr[i];

            if (map.containsKey(ch)) {
                if (!map.get(ch).equals(word)) {
                    return false;  // If the pattern's character already maps to a different word
                }
            } else {
                if (map.containsValue(word)) {
                    return false;  // If a different pattern character already maps to this word
                }
                map.put(ch, word);  // Map the pattern character to the current word
            }
        }

        return true;
    }
}
