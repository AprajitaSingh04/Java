package Leetcode;

import java.util.*;

// leetcode 49
public class GroupAnagram {

    public static void main(String[] args) {
        String[] strs = {"eat", "tea", "tan", "ate" , "nat" , "bat"}; // Initialize the array properly
        System.out.println(groupAnagram(strs));
    }

        public static List<List<String>> groupAnagram(String[] strs) {
        Map<String, List> map = new HashMap<>();

        for (String s : strs) {
            char [] ch = s.toCharArray();
            Arrays.sort(ch);

            String sortedkey = new String(ch);
            if(!map.containsKey(sortedkey)){
                map.put(sortedkey, new ArrayList());

            }
            map.get(sortedkey).add(s);
        }
        return new ArrayList(map.values());
    }
}

/*
Step 1: Create a HashMap to store anagrams We create a HashMap called anagramMap to store the anagrams.
The key of the map will be the sorted version of the string, and the value will be a list of strings that are anagrams of
each other.

 Step 2: Iterate through the input array We iterate through the input array strs and process each
 string individually.

Step 3: Sort the characters of the string For each string, we convert it to a character array,
sort the characters, and then convert it back to a string. This gives us a sorted version of the
original string.

Step 4: Add the string to the anagram map We check if the sorted string is already a key in
the anagramMap. If it's not, we add it with a new list as its value. Then, we add the original
string to the list of anagrams for that key.

Step 5: Return the list of anagram groups Finally, we return a list of the values in the
anagramMap, which are the groups of anagrams.*/
