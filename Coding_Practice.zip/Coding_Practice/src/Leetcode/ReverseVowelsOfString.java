package Leetcode;
import java.util.HashSet;
import java.util.Set;
// leetcode 345
public class ReverseVowelsOfString {
    public String reverseVowels(String s) {
        char[] arr = s.toCharArray();
        Set<Character> vowels = new HashSet<>();
        System.out.println("The given string is: " +s );

        vowels.add('A');
        vowels.add('E');
        vowels.add('I');
        vowels.add('O');
        vowels.add('U');
        vowels.add('a');
        vowels.add('e');
        vowels.add('i');
        vowels.add('o');
        vowels.add('u');

        int start = 0;
        int end = arr.length - 1;

        while(start < end){
            while(start<end && !vowels.contains(arr[start])){
                start++;
            }
            while(start<end && !vowels.contains(arr[end])){
                end--;
            }
            char temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
return new String(arr) ;
    }
        public static void main(String[] args) {

            ReverseVowelsOfString r = new ReverseVowelsOfString();
         //   System.out.println(reverseVowels("Hello")); // if the static method is static
            System.out.println(r.reverseVowels("Hello"));

        }
    }
