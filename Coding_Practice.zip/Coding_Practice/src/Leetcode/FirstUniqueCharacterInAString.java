package Leetcode;
public class FirstUniqueCharacterInAString {
    public static void main(String[] args) {
        //  String s = "SUMMERS";
         System.out.println(firstuniquecharacter("loveleetcode")); // leetcode 387
       // System.out.println(firstuniquecharacter("SUMMERS"));
       // System.out.println(firstuniquecharacter("aabb"));


    }

// 1st Approach
/*    static int firstuniquecharacter(String s){
        int[] freq = new int[26];
        char[] chars = s.toCharArray();

        for (char c: chars){
            freq[c - 'a']++;
        }

        for (int i = 0; i< chars.length ; i++){

            if (freq[chars[i] - 'a'] == 1){
                return i;
            }

        }
        return -1;
    }*/

// 2nd Approach

        static int firstuniquecharacter (String s){

            for (int i = 0; i < s.length(); i++) {
                int count = 0;

                for (int j = 0; j < s.length(); j++) {
                    if (s.charAt(i) == s.charAt(j)) {
                        count++;

                    }
                }
                if (count == 1) {
                    System.out.println("First unrepeated character is: " + s.charAt(i));
                    return i; // index
                }

            }
            return -1;

        }
    }




