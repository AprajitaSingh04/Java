package Leetcode;
public class ReverseWordsInAString {

    public static void main(String[] args) {
        System.out.println(reverseWords("The Sky is Blue")); // leetcode 151
        System.out.println(reverseWords("   Hello  World    "));
        System.out.println(reverseWords("a good     example"));
    }


    public static String reverseWords(String s) {

        String[] words = s.split(" +");

        StringBuilder sb = new StringBuilder();
        for(int i = words.length - 1 ; i>= 0; i-- ){
                sb.append(words[i]);
                sb.append(" ");
        }
        return sb.toString().trim();
    }
}