package Leetcode;
// leetcode 1768
public class MergeString {

    public String mergerAlternately(String words1, String words2) {

        int n1 = words1.length();
        int n2 = words2.length();
        int i = 0;

        StringBuilder sb = new StringBuilder();

        while (i < n1 || i < n2) {
            if (i < n1)
                sb.append(words1.charAt(i));
            if (i < n2)
                sb.append(words2.charAt(i));

            i++;
        }

        return sb.toString();
    }

    public static void main(String[] args) {
        MergeString m = new MergeString();
        System.out.println(m.mergerAlternately("abc","pqr"));

    }
}