package InterView;


class Example {
    static void staticMethod() {
        System.out.println("Static method called.");
    }
}

public class staTicMethod {
    public static void main(String[] args) {
        Example obj = new Example();

        // Calling static method with object reference (not recommended)
        obj.staticMethod();

        // Preferred way: Calling static method using class name
        Example.staticMethod();
    }
}
