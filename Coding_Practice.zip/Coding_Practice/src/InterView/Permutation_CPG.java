package InterView;

import java.util.ArrayList;
import java.util.List;

/*
public class Permutation_CPG {
    private static String swapString(String a, int i, int j){
        char[] ch = a.toCharArray();
        char temp;
        temp = ch[i];
        ch[i] = ch[j];
        ch[j] = temp;

       // return String.valueOf(ch);
        return new String(ch);
    }

    private static void generatePermutation(String str, int start, int end, List<String> permute){

        if(start == end ){
            //System.out.println(str);
            permute.add(str);

        }
        else{
            for(int i = start; i <= end; i++){
                str = swapString(str,start,i);
                generatePermutation(str, start+1,end,permute);
                str = swapString(str,start,i);
            }
        }

    }

    public static void main(String args[]){
        String str = "GOD";
        List<String> permute = new ArrayList<>();
        System.out.println("All the Permutations of the String are: " );
        generatePermutation(str, 0,str.length()-1, permute);
        System.out.println(permute);
        System.out.println(permute.size());


    }
}

*/

public class Permutation_CPG {
    public static void main(String[] args) {
        String str = "GOD";
        List<String> permutation = new ArrayList<>();
        System.out.println("All the permutations of the String are: ");
        generatePermutations(str,0,str.length()-1,permutation);
        System.out.println(permutation);
        System.out.println(permutation.size());


    }
    private static String swapString(String a, int i, int j){
        char[] ch = a.toCharArray();
        char temp = ch[i];
        ch[i] = ch[j];
        ch[j] = temp;
        return new String(ch);
    }


    private static void generatePermutations(String str, int start, int end,List<String> permutation ){
        if(start == end){
            permutation.add(str);
        }
        else{
            for(int i = start; i<=end; i++){
                str = swapString(str,start,i);
                generatePermutations(str,start+1,end, permutation);
                str = swapString(str,start,i);


            }
        }

    }
}
