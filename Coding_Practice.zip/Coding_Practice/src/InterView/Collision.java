package InterView;

import java.util.HashMap;
import java.util.Map;

public class Collision {

    public static void main(String args[]){
/*
        Map<String,Integer> map = new HashMap<>();

        map.put( "John", 10);
        map.put( "Jon", 20);

        System.out.println(map.get("John")); // 10
        System.out.println(map.get("Jon")); //20
        */

        Map<String, Integer> map = new HashMap<>();

        map.put("John", 10);
        map.put("Jon", 20);

        System.out.println("Hash code for 'John': " + "John".hashCode());
        System.out.println("Hash code for 'Jon': " + "Jon".hashCode());

     //   Hash code for 'John': 2314539
     //   Hash code for 'Jon': 74665

    }

}
