package InterView;

// Method Overriding
public class Questions {

    Integer method1(Integer i){
        System.out.println("Method1 from A");
        return 1;
   }

}

  class B extends Questions {
    Integer method1(Object o ){
        System.out.println("Method1 from B");
        return 1;
    }

    public static void main(String args[]) {
        Questions a = new B();
        a.method1(1); // Method1 from A
    }

}
