package InterView;

public class SuperThis {

    SuperThis() {
        super();
      //  this(); // compilation err
        System.out.println("Parent Constructor");
    }


/*class Child extends SuperThis {
    Child() {
        this("Default");
        System.out.println("Child Constructor");
    }

    Child(String msg) {
        super(); // Calls parent class constructor
        System.out.println("Child Constructor with Message: " + msg);
    }*/

    public static void main(String[] args) {
        SuperThis s =  new SuperThis();
    }
}
