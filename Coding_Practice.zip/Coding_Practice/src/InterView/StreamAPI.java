package InterView;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Collectors;

public class StreamAPI {
    public static void main(String args[]) {
        List<Integer> numbers = Arrays.asList(1, 2, 6, 4, 3, 5);

        // number multiply by 2
        numbers.stream().map(n -> n * 2).forEach(System.out::println); // use map

        // number is greater than 2
        numbers.stream().filter(n -> n > 2).forEach(System.out::println); // use filter

        // sort the list

        List<Integer> sortedList = numbers.stream().sorted().collect(Collectors.toList());
        System.out.println("SortedList:" + sortedList);

        //reverse

        List<Integer> reverseList = numbers.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        System.out.println("SortedList:" + reverseList);

        // evenNumber

        List<Integer> EvenNumber = numbers.stream().filter(n -> n % 2 == 0).collect(Collectors.toList());
        System.out.println(EvenNumber);

        numbers.stream().filter(n -> n % 2 == 0).forEach(System.out::println);
        System.out.println("EvenNumber is:" + EvenNumber);

        // oddNumber

        List<Integer> OddNumber = numbers.stream().filter(n -> n % 2 != 0).collect(Collectors.toList());
        System.out.println(OddNumber);

        numbers.stream().filter(n -> n % 2 != 0).forEach(System.out::println);
        System.out.println("OddNumber is: " + OddNumber);


        // min & max

        int min = numbers.stream().min((x, y) -> x - y).get(); // get is an optional class method
        System.out.println("min is: " + min);

        int max = numbers.stream().max((a, b) -> a - b).get();
        System.out.println("max is: " + max);

        // sort the Employee List

        List<String> Emp = Arrays.asList("Appu", "Kaju", "Balak", "Zoobie");

        // List<String> SortedList = Emp.stream().sorted(Comparator.comparing(Emp::getEmpId).thenComparing(Emp::getEmpName)).collect(Collectors.toList());

        List<String> SortedList = Emp.stream().sorted().collect(Collectors.toList());
        System.out.println(SortedList);

        // group Employees on behalf of department

        // List<String> GroupEmp = Emp.stream().collect(Collectors.groupingBy(Emp::getGender, Collectors.counting()));
        // System.out.println(GroupEmp);

        //Stream API

        List<String> list = Arrays.asList("Ahmedabad", "bth", "canada", "dehradun");

        list.stream()
                .map(String::toUpperCase)
                .filter(name -> name.startsWith("A"))
                .forEach(System.out::println); // AHMEDABAD

                /*.collect(Collectors.toList());
                 System.out.println(list);*/


        // Find the second largest number in the list
        List<Integer> nums = Arrays.asList(10, 20, 35, 50, 50, 75, 65);

        // Step 1: Find the second largest number in the list
        Optional<Integer> secondLargest = nums.stream()
                .distinct() // Step 2: Remove duplicates
                .sorted(Comparator.reverseOrder()) // Step 3: Sort in descending order
                .skip(1) // Step 4: Skip the first (largest) number
                .findFirst(); // Step 5: Get the second largest number

        // Step 6: Display the result
        if (secondLargest.isPresent()) {
            System.out.println("The second largest number is: " + secondLargest.get());
        } else {
            System.out.println("The list does not have enough unique numbers.");
        }


        //  3rd Largest element in the list without sorted function?

        List<Integer> list2 = Arrays.asList(10, 80, 20, 40, 30);

        Optional<Integer> ThirdLargestElement = list2.stream()
                .distinct()
                .sorted(Comparator.reverseOrder())
                .skip(2)
                .findFirst();
        System.out.println("The Third largest number is:" + ThirdLargestElement.get());

        //  4th Largest element in the list without sorted function?

        List<Integer> list4 = Arrays.asList(90, 40, 20, 10, 5, 20, 84);

        Optional<Integer> FourthLargest = list4.stream()
                .distinct()
                .sorted(Comparator.reverseOrder())
                .skip(3)
                .findFirst();

        System.out.println("The Fourth largest number is:" + FourthLargest.get());

        List<Integer> list5 = Arrays.asList(23, 43, 12, 12);

        // Find duplicates using Stream API
        Set<Integer> dupNum = new HashSet<>();
        List<Integer> duplicates = list5.stream()
                .filter(n -> !dupNum.add(n)) // Add to the set, filter returns true if already added
                .collect(Collectors.toList());

        // Print duplicates
        System.out.println("Duplicates: " + duplicates);


        // Count male employees in each department
        // Map<String, Long> emp = list4.stream().filter(e ->e.getGender()).collect(Collectors.groupingBy(Employee:: getDepartment, Collectors.counting()));
        // System.out.println("The largest number is:" + emp);

        /*
        List<Integer> list5 = Arrays.asList(23,43,12,12);

        Set<Integer> duplicates = new HashSet<Integer>();
        Set<Integer> dup =   list5.stream()
                .filter(e -> !duplicates.add(e)) // Add to the set, filter returns true if already added
                .collect(Collectors.toSet());

        System.out.println("Duplicates: " + duplicates);*/

    }


}