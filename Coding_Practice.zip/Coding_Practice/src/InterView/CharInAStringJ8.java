package InterView;
// lambda expression example
import java.util.Arrays;
import java.util.List;

public class CharInAStringJ8 {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(10, 20, 30);

        // Using lambda expression to print each character
        list.stream()
                .map(String::valueOf) // Convert each Integer to String
                .forEach(s -> s.chars()
                        .mapToObj(c -> (char) c) // Convert int to Character
                        .forEach(System.out::println));
    }
}
