package InterView;
import java.util.Comparator;


public class TreeSet {
    public static void main(String[] args) {
       // TreeSet<Integer> treeSet = new TreeSet<Integer>();
        java.util.TreeSet<Integer> treeSet = new java.util.TreeSet<>();

        treeSet.add(10);
        treeSet.add(5);
        treeSet.add(20);
        treeSet.add(10); // Duplicate, will not be added
       // treeSet.add(null);// Throws NullPointerException

        System.out.println(treeSet); // Output: [5, 10, 20]

      /*  TreeSet<String> treeSet = new TreeSet<>(Comparator.naturalOrder());
        treeSet.add(null);*/ // Throws NullPointerException
    }
}


