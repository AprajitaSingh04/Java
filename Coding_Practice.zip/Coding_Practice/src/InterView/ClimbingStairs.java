package InterView;

public class ClimbingStairs {


    public static void main(String[] args) {
        int n = 6;  // input n =5
        System.out.println("Number of ways to climb " + n + " stairs: " + climbStairs(n));
    }


    public static int climbStairs(int n) {
        if(n<=3){
            return n;
        }
        int a =3,b=2;
        for(int i = 0;i<n-3;i++){
            a=a+b;
            b=a-b;

        }
        return a;
    }


}


/*

// Accolite
if n= 2, output will be 2
 if n= 3, output will be 3
  if n= 5, output will be 8
 if n= 6, output will be 13

 */

// 2nd Approach

    /* public class ClimbingStairs {

            // Function to calculate the number of ways to climb 'n' stairs
            public static int climbStairs(int n) {
                if (n == 0) {
                    return 0; // If there are 0 stairs, no way to climb.
                }
                if (n == 1) {
                    return 1; // One way to climb 1 step (one step).
                }
                if (n == 2) {
                    return 2; // Two ways to climb 2 steps (1+1 or 2).
                }

                // Variables to store the previous two results
                int first = 1;  // Ways to reach the first step
                int second = 2; // Ways to reach the second step
                int result = 0;

                // Loop from the 3rd step to the nth step
                for (int i = 3; i <= n; i++) {
                    result = first + second;  // Number of ways to reach current step
                    first = second;           // Update first to second (i-1)
                    second = result;          // Update second to current result (i)
                }

                return result;
            }

            public static void main(String[] args) {
                int n = 5;  // Example input
                System.out.println("Number of ways to climb " + n + " stairs: " + climbStairs(n));
            }
        }*/

