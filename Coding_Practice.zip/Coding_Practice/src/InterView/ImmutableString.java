package InterView;

public class ImmutableString {
    public static void main(String args[]){

        // String Literal
        String a = "Appuuuuuuu";
        System.out.println(a); // Appuuuuuuu

        String b = "Appuuuuuuu";
        System.out.println(b); // Appuuuuuuu

        //Immutable
        a.concat("Singhhh");
        System.out.println(a); // Appuuuuuuu

        a = a.concat("Singhhh");
        System.out.println(a); //AppuuuuuuuSinghhh

        // New keyword
        String ab = new String ("Apra");
        System.out.println(ab); // Apra

        String ba = new String ("Apra");;
        System.out.println(ba); // Apra

        //Immutable
        ab.concat("Singh");
        System.out.println(ab); //Apra

        // assignment operator
        ab = ab.concat("Singh");
        System.out.println(ab); //ApraSingh

        String str1= "hello";
        String str2= str1; //  String str2= "hello";

        System.out.println(str1 == str2); // true
        System.out.println(str1.equals(str2)); // true

        // immutable
        str1.concat("there"); // no change

        System.out.println(str1 == str2); // true
        System.out.println(str1.equals(str2)); // true


        String str3 = new String("Hello");
        String str4 = new String("Hello");

        System.out.println(str3 == str4); // false




}
}