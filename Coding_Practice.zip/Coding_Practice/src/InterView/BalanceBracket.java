package InterView;
import java.util.Stack;

   public class BalanceBracket {

        public static boolean isBalanced(String s) {
            Stack<Character> stack = new Stack();
            for (char ch : s.toCharArray()) {
                if ((ch == '{') || ch == '(' || ch == '[') {
                    stack.push(ch);
                } else if (ch == '}' || ch == ']' || ch == ')') {
                    if (stack.isEmpty()) {
                        return false;
                    }
                    char top = stack.pop();
                    if ((ch == '}' && top != '{' ||
                            ch == ')' && top != '(' ||
                            ch == ']' && top != '[')) {
                        return false;
                    }

                }
            }
            return stack.isEmpty();
        }

        public static void main(String[] args) {
            // Test cases
            String s1 = "{[()]}";
            String s2 = "{{[)";

            System.out.println("Is string \"" + s1 + "\" balanced: " + isBalanced(s1)); // true
            System.out.println("Is string \"" + s2 + "\" balanced: " + isBalanced(s2)); // false
        }
    }

