package InterView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ImmutableClass {
    private final List<String> list;
    private final String name;

    public ImmutableClass(String name, List<String> subjects) {
        this.name = name;
        // Create an unmodifiable copy of the list to ensure immutability
        this.list = Collections.unmodifiableList(new ArrayList<>(subjects));
    }

    public String getName() {
        return name;
    }

    public List<String> getList() {
        // Return a defensive copy to prevent external modifications
        return new ArrayList<>(list);
    }
}
