package InterView;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ThirdLargestInAList {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(12, 35, 1, 10, 34, 1);

        // Find the first largest
        Optional<Integer> firstLargest = numbers.stream().max(Integer::compareTo);
        if (!firstLargest.isPresent()) {
            System.out.println("List is empty");
            return;
        }

        // Find the second largest by excluding the first largest
        Optional<Integer> secondLargest = numbers.stream()
                .filter(num -> !num.equals(firstLargest.get()))
                .max(Integer::compareTo);
        if (!secondLargest.isPresent()) {
            System.out.println("No second largest element");
            return;
        }

        // Find the third largest by excluding the first and second largest
        Optional<Integer> thirdLargest = numbers.stream()
                .filter(num -> !num.equals(firstLargest.get()) && !num.equals(secondLargest.get()))
                .max(Integer::compareTo);

        if (thirdLargest.isPresent()) {
            System.out.println("The third largest element is: " + thirdLargest.get());
        } else {
            System.out.println("No third largest element");
        }
    }
}
