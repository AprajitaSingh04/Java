package InterView;

import java.util.ArrayList;
import java.util.List;
/*
public class PermutationString {

    //Function for swapping the characters at position I with character at position j
    public static String swapString(String a, int i, int j) {
        char[] b =a.toCharArray();
        char ch;
        ch = b[i];
        b[i] = b[j];
        b[j] = ch;
        return String.valueOf(b);
    }

    public static void main(String[] args)
    {
        String str = "GOD";
        int len = str.length();
        System.out.println("All the permutations of the string are: ");
        generatePermutation(str, 0, len);
    }

    //Function for generating different permutations of the string
    public static void generatePermutation(String str, int start, int end)
    {
        //Prints the permutations
        if (start == end-1)
            System.out.println(str);
        else
        {
            for (int i = start; i < end; i++)
            {
                //Swapping the string by fixing a character
                str = swapString(str,start,i);
                //Recursively calling function generatePermutation() for rest of the characters
                generatePermutation(str,start+1,end);
                //Backtracking and swapping the characters again.
                str = swapString(str,start,i);
            }
        }
    }
}


*/
/*
public class PermutationString {
    static void printPermutation(String input, String result){

        // if the String empty

        if(input.length() == 0){
            System.out.println(result + " ");
            return;
        }
        for( int i = 0; i<input.length();i++){
            char ch = input.charAt(i);

            String rest = input.substring(0,i) + input.substring(i+1);
            printPermutation(rest, result+ch);

        }
    }
    public static void main (String args[]){
        String inputString = "GOD";
        printPermutation(inputString, "");
    }
}

*/



public class PermutationString {

public static void main(String[] args) {
    String str = "GOD";
    List<String> permutations = new ArrayList<>();

    // Generate all permutations
    generatePermutations(str, 0, str.length() - 1, permutations);
   // Print the permutations
            System.out.println(permutations);

    // Print the number of permutations
            System.out.println(permutations.size());
        }

// Function to generate permutations
private static void generatePermutations(String str, int start, int end, List<String> permutations) {
    if (start == end) {
        permutations.add(str);
    } else {
        for (int i = start; i <= end; i++) {
            str = swapString(str, start, i); // Swap the characters
            generatePermutations(str, start + 1, end, permutations); // Recurse for next position
            str = swapString(str, start, i); // Backtrack to original state
        }
    }
}

// Helper function to swap characters in a string
    private static String swapString(String a, int i, int j){
        char[] ch = a.toCharArray();
        char temp;
        temp = ch[i];
        ch[i] = ch[j];
        ch[j] = temp;
        return new String(ch);

    }
    }