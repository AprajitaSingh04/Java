package InterView;

// 1st Approach
public class Palindrome_String {
    public static void main(String[] args){
        String str = "level"; // MADAM/Radar/Rotor
        String rev = "";

        for(int i = str.length()- 1; i>=0;i--){
            rev = rev+str.charAt(i);
        }
        if(str.toLowerCase().equals(rev.toLowerCase())){
            System.out.println("Palindrome String");

        }
        else{
            System.out.println("Not A Palindrome String");

        }
    }
}

// 2nd Approach
/*
import java.util.Scanner;

public class Palindrome_String {
    public static void main(String[] args){


        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a word: ");
        String s = sc.nextLine();
        String rev ="";

        for(int i = 0; i<s.length();i++)
            {
            rev = s.charAt(i)+ rev; // Adding from left
        }
        if(s.equalsIgnoreCase(rev)){
            System.out.println("Palindrome String");

        }
        else{
            System.out.println("Not A Palindrome String");

        }
    }
}*/
