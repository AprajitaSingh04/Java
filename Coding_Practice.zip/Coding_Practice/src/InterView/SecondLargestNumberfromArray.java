package InterView;

import java.util.Arrays;

public class SecondLargestNumberfromArray {

    public static void print2Largest(int arr[]){
        int size = arr.length;
        if(size<2){
            System.out.println("Invalid Input");
            return;
        }
        Arrays.sort(arr);
        for(int i = size - 2; i>=0;i--){
            if(arr[i] != arr[size - 1]){
                System.out.println("The second largest element is: " +arr[i]);
                return;
            }
        }
        System.out.println("There is no second largest element");
    }
    public static void main(String args[]) {
        int arr[] = {1,4,5,35,35,35,34}; // {1,4,5,35,35,34}
        print2Largest(arr);

    }

}
