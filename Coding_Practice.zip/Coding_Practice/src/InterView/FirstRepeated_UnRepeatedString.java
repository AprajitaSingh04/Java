package InterView;
//Using collections ?

public class FirstRepeated_UnRepeatedString {

    public static void main(String[] args){
        String s = "LoveLeetCode"; // SUMMERS

      //  Scanner sc = new Scanner(System.in);
      //  String s = sc.nextLine();
        System.out.println("The given string is: " +s );

        for (int i = 0; i <s.length(); i++) {
            int count = 0;

            for (int j = 0; j < s.length(); j++) {
                if (s.charAt(i) == s.charAt(j)) {
                    count++;

                }
            }
            if (count == 1) {
                System.out.println("First unrepeated character is: " + s.charAt(i));
                break;
            }
           /* if (count > 1) {
                System.out.println("First repeated character is: " + s.charAt(i));
                break;
            }*/

        }

   }
}



