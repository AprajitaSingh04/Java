/*
package InterView;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class UsingJ8_FirstNonRepeatedChar {


    public static void main(String[] args) {
        String input = "swiss";

        Optional<Character> firstNonRepeated = input.chars() // Stream the characters
                .mapToObj(c -> (char) c) // Convert each int to a char
                .collect(LinkedHashMap::new, // Use a LinkedHashMap to maintain insertion order
                        (map, c) -> map.put(c, map.getOrDefault(c, 0) + 1),
                        Map::putAll)
                .entrySet()
                .stream()
                .filter(entry -> entry.getValue() == 1) // Filter characters with count = 1
                .map(Map.Entry::getKey) // Extract the character
                .findFirst(); // Get the first non-repeated character

        // Display the result
        firstNonRepeated.ifPresentOrElse(
                character -> System.out.println("First non-repeated character: " + character),
                () -> System.out.println("No non-repeated character found")
        );
    }
}
*/
