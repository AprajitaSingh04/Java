package InterView;
class Human {

        public int walk(int distance, int time) {
            int speed = distance / time;
            return speed;
            // System.out.println("super speed: " +speed);
        }
    }
    class Athlete extends  Human {
        public int walk(int distance, int time) {
            //   super.walk(1000,500);
            int speed = distance / time;
            speed = speed * 2;
            return speed;
            //  System.out.println("sub speed: " +speed);

        }
    }
    public class Overiding_interview {
        public static void main (String args[]){
            Human s = new Athlete();
            int walk1 = s.walk(500,25);
          //  int walk2 = s.walk(200, 40);
            System.out.println(walk1);
          //  System.out.println(walk2);
            //  s.walk(500,25);
        }
    }
