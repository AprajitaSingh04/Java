package InterView;
public class String_Comparison {

    public static void main(String args[]) {
        /*String str = null;
        System.out.print(str.length()); // exception*/

       // String defined in 2 ways
        String a = "Tiger"; // String Literal // SCP
        String b = new String ("Tiger"); // new keyword - Heap memory
        String c = "Tiger";

        if(a ==b) // False (equal equal operator)
        {
            System.out.print("True");
        }
        else {
            System.out.print("False");
        }
        if(a.equals(b)) // True (equals method)
        {
            System.out.print("\nTrue");
        }
        else {
            System.out.print("\nFalse");
        }
        if(c ==a) // True (equal equal operator)
        {
            System.out.print("\nTrue");
        }
        else {
            System.out.print("\nFalse");
        }
    }
}
