package Learning;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        final Integer age;
        age=10;
        System.out.println("Age:" +age); // Age:10
    }
}