package Learning;

public class AOP_SpringbootFeatures {
 /*
@Aspect
public class LoggingAspect {
    @Before("execution(* *(..))")
    public void logMethodCall(JoinPoint joinPoint) {
        System.out.println("Method called: " + joinPoint.getSignature().getName());
    }
}*/

}


/*
AOP stands for Aspect-Oriented Programming, which is a programming paradigm that focuses on modularizing cross-cutting concerns, such as error handling, security, caching, and logging, that cut across multiple classes and objects.

In Spring Boot, AOP is implemented using the AspectJ framework, which provides a powerful way to implement aspects that can be woven into the application code.

Here are the key features of AOP in Spring Boot:

1. Aspects: An aspect is a class that implements a cross-cutting concern, such as logging or security. Aspects are typically implemented using annotations, such as @Aspect.
2. Joinpoints: A joinpoint is a specific point in the execution of the application, such as a method call or exception handling. Aspects can be woven into the application at these joinpoints.
3. Advice: Advice is the code that is executed at a joinpoint. There are several types of advice, including:

* **Before advice**: Executed before the joinpoint.
* **After advice**: Executed after the joinpoint.
* **Around advice**: Executed around the joinpoint, allowing for more complex logic.
* **Throws advice**: Executed when an exception is thrown at the joinpoint.

4. Pointcuts: A pointcut is a predicate that matches joinpoints. Pointcuts are used to determine which joinpoints an aspect should be applied to.
5. Weaving: Weaving is the process of combining aspects with the application code. In Spring Boot, weaving is done at runtime using a proxy-based approach.
Some common use cases for AOP in Spring Boot include:

Logging: Implementing logging aspects to log method calls and exceptions.
Security: Implementing security aspects to enforce access control and authentication.
Caching: Implementing caching aspects to cache method results.
Error handling: Implementing error handling aspects to handle exceptions in a centralized way.

*/
