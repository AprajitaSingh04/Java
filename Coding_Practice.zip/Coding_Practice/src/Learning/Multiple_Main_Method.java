package Learning;
public class Multiple_Main_Method {

    public static void main(String[] args) {
        System.out.println("Main method 1");
    }
    // This will cause a compiler error - method main(String[]) is already defined in class
    /* public static void main(String[] args) {
        System.out.println("Main method 2");
     }*/
    public static void main(String args) {
        System.out.println("Another main method");
    }

    public static void main(int args) {
        System.out.println("3rd main method");
    }
}


// MultipleMainMethods.java
/*
public class Multiple_Main_Method {
    public static void main(String[] args) {
        System.out.println("Main method 1");
    }

    // This will cause a compiler error
    // public static void main(String[] args) {
    //     System.out.println("Main method 2");
    // }
}

// AnotherMainMethod.java
public class AnotherMainMethod {
    public static void main(String[] args) {
        System.out.println("Another main method");
    }
}*/
