package Learning;
import java.util.Arrays;

public class Anagram{
    public static void main (String args[]){
        // import two String
        String s1 = "CAT";
        String s2 = "ACT"; // CAT and ACT are anagram
       // String s2 = "RAT"; //CAT and RAT are not anagram

        // find if both the strings are anagram or not
        if (areAnagram( s1,  s2)){
            System.out.println (s1 + " and " + s2 + " are anagram");
        }
        else {
            System.out.println (s1 + " and " + s2 + " are not anagram");
        }

        // System.out.println("S1 and S2 are Anagram?: " +areAnagram(s1,s2));
        /*Coding c = new Coding();
        c.areAnagram(s1, s2);
        System.out.println("S1 and S2 are Anagram");*/
    }
    public static boolean areAnagram ( String s1, String s2){
        // check the length
        if (s1.length() != s2.length()){
            return  false;
        }
        // convert string into char array

        char[] charArray1 = s1.toCharArray();
        char[] charArray2 = s2.toCharArray();

        // sort the char Array

        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        // compare the sorted char Array

        return Arrays.equals(charArray1,charArray2);

    }

}