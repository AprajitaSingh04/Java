package Learning;
public class LiveReload {
}

/*
LiveReload is a feature in Spring Boot that allows you to see changes to your application's code
reflected in the browser without needing to manually restart the server. It's a development tool
 that improves productivity by reducing the time it takes to test and iterate on changes.

When LiveReload is enabled, Spring Boot automatically restarts the application
 when it detects changes to the code. This is typically done by monitoring the project's
 class files and restarting the application when a change is detected.

To use LiveReload in Spring Boot, you'll need to add the Spring Boot DevTools
dependency to your project. You can do this by adding the following dependency
to your pom.xml file (if you're using Maven) or your build.gradle file (if you're using Gradle):*/

/*<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-devtools</artifactId>
    <optional>true</optional>
</dependency>*/

// Once you've added the dependency, you can enable LiveReload by setting the spring.devtools.restart.enabled
// property to true in your application.properties or application.yml file:

/*
spring.devtools.restart.enabled=true
*/


//application.yml:

/*
spring:
devtools:
restart:
enabled: true*/

// Singleton
/*public final class Singleton {

    private static Singleton instance;

    private Singleton() {

    }

    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }
}*/
