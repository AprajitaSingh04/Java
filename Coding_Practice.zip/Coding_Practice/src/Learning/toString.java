/*Overriding toString()
You can override toString() in your classes to provide a more meaningful representation:*/

/*

In Java, the toString() method is used to provide a string representation of an object.
This method is defined in the Object class, which is the root class of all Java classes,
 so every class inherits it.

Here’s why and how you might use toString():

Purpose of toString()
Readable Output: toString() is commonly overridden to provide a more readable or useful
string representation of an object, making it easier to understand when the object is printed or logged.

Debugging: It helps in debugging by giving a clear textual representation of the
object's state.

Logging: When logging objects, a meaningful string representation can make log messages more informative.
*/
package Learning;
public class toString {
    private String name;
    private int age;

    public toString(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
       // return "toString{name='" + name + "', age=" + age + "}";

    }

    public static void main(String[] args) {
        toString person = new toString("Alice", 30);
        System.out.println(person); // Output: Person{name='Alice', age=30}
    }
}



/*
Default Implementation:
The default implementation of toString() in the Object class returns a string that consists of the class name
followed by the "@" character and the object's hashcode in hexadecimal.


Object obj = new Object();
System.out.println(obj.toString()); // Output might be something like "java.lang.Object@1a2b3c4d"*/
