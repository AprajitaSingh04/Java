package Practice2025;
import java.util.*;
import java.util.stream.Collectors;


// // Find the duplicate words in a string, Array of Strings and list of strings in java with Java 8 features.


/*// String
public class DuplicatesWordsInAStringUsingJ8 {
    public static void main(String[] args) {
         String input = "this is a test this is a sample test";

        // Split the string into words and count duplicates using Java 8 Streams
        Arrays.stream(input.split(" "))
                .map(String::toLowerCase)  // Convert to lowercase for case-insensitivity
                .collect(Collectors.groupingBy(word -> word, Collectors.counting()))  // Group by word and count occurrences
                .entrySet().stream()
                .filter(entry -> entry.getValue() > 1)  // Filter out words that appear more than once
                .forEach(entry -> System.out.println(entry.getKey() + " : " + entry.getValue()));  // Print duplicates
    }
}*/

/*// Array of String
public class DuplicatesWordsInAStringUsingJ8 {
    public static void main(String[] args) {
        String[] input = {"Hey", "java", "is", "a", "best", "language", "is", "java", "best"};

        // Use Java 8 Streams to find duplicates in array
        Arrays.stream(input)
                .map(String::toLowerCase)  // Convert to lowercase for case-insensitivity
                .collect(Collectors.groupingBy(word -> word, Collectors.counting()))  // Group by word and count occurrences
                .entrySet().stream()
                .filter(entry -> entry.getValue() > 1)  // Filter out words that appear more than once
                .forEach(entry -> System.out.println(entry.getKey() + " : " + entry.getValue()));  // Print duplicates
    }
}*/

// List of String

public class DuplicatesWordsInAStringUsingJ8 {
    public static void main(String[] args) {
            List<String> input = Arrays.asList("Hey", "java", "is", "a", "best", "language", "is", "java", "best");

            // Use Java 8 Streams to find duplicates in list
            input.stream()
                    .map(String::toLowerCase)  // Convert to lowercase for case-insensitivity
                    .collect(Collectors.groupingBy(word -> word, Collectors.counting()))  // Group by word and count occurrences
                    .entrySet().stream()
                    .filter(entry -> entry.getValue() > 1)  // Filter out words that appear more than once
                    .forEach(entry -> System.out.println(entry.getKey() + " : " + entry.getValue()));  // Print duplicates
        }
    }
