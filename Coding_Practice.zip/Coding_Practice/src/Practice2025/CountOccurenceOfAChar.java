package Practice2025;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountOccurenceOfAChar {
    public static void main(String[] args) {
        String s = "asdfsad asa asdf asdfasd";

        // Count occurrences of each character
        Map<Character, Long> charCount = s.chars()
                .mapToObj(c -> (char) c) // Convert int to Character
                .filter(c -> c != ' ') // Exclude spaces
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        // Print the result
        charCount.forEach((k, v) -> System.out.println(k + ": " + v));
    }
}

