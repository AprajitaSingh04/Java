package Practice2025;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

// Find the duplicate words in a string, Array of Strings and list of strings in java without Java 8 features.
public class DuplicatesWordsInAString {
    public static void main(String[] args) {
       findDuplicateWords("Hey java is a best language, is java the best?");
        findDuplicateWords("100 300 800 622 300 ");

    }


    public static void findDuplicateWords(String inputString){
        // split
        String words[] = inputString.split(" ");

        // create one Hashmap
        Map<String, Integer> wordCount = new HashMap<String, Integer>();

        // to check each word in given array
        for(String word: words){

            //if word is present
            if(wordCount.containsKey(word)){
                wordCount.put(word, wordCount.get(word)+1);
            }
            else{
                wordCount.put(word,1);
            }
        }
        // extracting all the keys of map - wordCount
        Set<String> wordsInString = wordCount.keySet();

        // loop through all the words in wordCount:
        for(String word: wordsInString){
            if(wordCount.get(word)>1){
                System.out.println(word+ " : "+ wordCount.get(word) );
            }
        }
    }


}


/*

// Array of String

// Find the duplicate words in a string, Array of Strings and list of strings in java with or without Java 8 features.
public class DuplicatesWordsInAString {
    public static void main(String[] args) {
        // Array of String
        findDuplicateWords();

    }


    public static void findDuplicateWords(){
        // Array of String
        String[] words = {"this", "is", "a", "test", "this", "is", "a", "sample", "test"};

        // create one Hashmap
        Map<String, Integer> wordCount = new HashMap<String, Integer>();

        // to check each word in given array
        for(String word: words){

            //if word is present
            if(wordCount.containsKey(word)){
                wordCount.put(word, wordCount.get(word)+1);
            }
            else{
                wordCount.put(word,1);
            }
        }
        // extracting all the keys of map - wordCount
        Set<String> wordsInString = wordCount.keySet();

        // loop through all the words in wordCount:
        for(String word: wordsInString){
            if(wordCount.get(word)>1){
                System.out.println(word+ " : "+ wordCount.get(word) );
            }
        }
    }


}
*/

/*
// List of String

// Find the duplicate words in a string, Array of Strings and list of strings in java with or without Java 8 features.
public class DuplicatesWordsInAString {
    public static void main(String[] args) {
        // List of String
        findDuplicateWords();
    }
    public static void findDuplicateWords(){
        // List of String
        List<String> words = List.of("this", "is", "a", "test", "this", "is", "a", "sample", "test");

        // create one Hashmap
        Map<String, Integer> wordCount = new HashMap<String, Integer>();

        // to check each word in given array
        for(String word: words){

            //if word is present
            if(wordCount.containsKey(word)){
                wordCount.put(word, wordCount.get(word)+1);
            }
            else{
                wordCount.put(word,1);
            }
        }
        // extracting all the keys of map - wordCount
        Set<String> wordsInString = wordCount.keySet();

        // loop through all the words in wordCount:
        for(String word: wordsInString){
            if(wordCount.get(word)>1){
                System.out.println(word+ " : "+ wordCount.get(word) );
            }
        }
    }


}


*/
