package Practice2025;

import java.util.*;
import java.util.stream.Collectors;

// Java 8

public class AlternatePositiveNegative {

    public static void rearrange(int[] arr) {
        // Convert the array to a List<Integer> for easier stream manipulation
        List<Integer> positive = Arrays.stream(arr)
                .filter(n -> n >= 0)
                .boxed()
                .collect(Collectors.toList());
        List<Integer> negative = Arrays.stream(arr)
                .filter(n -> n < 0)
                .boxed()
                .collect(Collectors.toList());

        // Initialize an index for placing elements into the result array
        int index = 0;

        // Create an empty list to store the rearranged elements
        List<Integer> result = new ArrayList<>();

        // Create iterators for the positive and negative lists
        Iterator<Integer> posIter = positive.iterator();
        Iterator<Integer> negIter = negative.iterator();


        // Alternate between positive and negative numbers
        while (posIter.hasNext() && negIter.hasNext()) {
            result.add(posIter.next()); // Add positive number
            result.add(negIter.next()); // Add negative number
        }
        // Add any remaining positive numbers
        while (posIter.hasNext()) {
            result.add(posIter.next());
        }
        // Add any remaining negative numbers
        while (negIter.hasNext()) {
            result.add(negIter.next());
        }

        // Convert the list back to an array
        for (int i = 0; i < result.size(); i++) {
            arr[i] = result.get(i);
        }
    }

    // Function to print the array
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] arr = {1, -2, 3, -4, 5, -6, 7, 8, 0, -9};

        System.out.println("Original array:");
        printArray(arr);

        rearrange(arr);

        System.out.println("Rearranged array:");
        printArray(arr);
    }
}
